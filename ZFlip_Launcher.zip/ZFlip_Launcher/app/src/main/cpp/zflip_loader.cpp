#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>

#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <string>
#include <unordered_map>

#include "shadowhook.h"
#include "zflip.h"

#define TAG "ZFlip"

// Registro doble: logcat + archivo (el mismo que muestra la pantalla «Registros» de la app).
static std::string g_logPath;

static void zlog_write(int prio, const char* tag, const char* msg) {
    __android_log_write(prio, tag, msg);
    if (g_logPath.empty()) return;
    FILE* f = fopen(g_logPath.c_str(), "a");
    if (!f) return;
    time_t now = time(nullptr);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char level = prio >= ANDROID_LOG_ERROR ? 'E' : prio == ANDROID_LOG_WARN ? 'W' : prio == ANDROID_LOG_DEBUG ? 'D' : 'I';
    fprintf(f, "%02d:%02d:%02d %c/%s: %s\n", tmv.tm_hour, tmv.tm_min, tmv.tm_sec, level, tag, msg);
    fclose(f);
}

static void zlog(int prio, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
static void zlog(int prio, const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    zlog_write(prio, TAG, buf);
}
#define LOGD(...) zlog(ANDROID_LOG_DEBUG, __VA_ARGS__)
#define LOGI(...) zlog(ANDROID_LOG_INFO, __VA_ARGS__)
#define LOGW(...) zlog(ANDROID_LOG_WARN, __VA_ARGS__)
#define LOGE(...) zlog(ANDROID_LOG_ERROR, __VA_ARGS__)

static const char* GAME_LIB = "libcocos2dcpp.so";

static JavaVM* g_vm = nullptr;
static jclass g_bridge = nullptr;          // com.zflip.launcher.ZflipBridge (global ref)
static jmethodID g_onMenuVisible = nullptr; // static void onMenuVisible(boolean)
static jmethodID g_toast = nullptr;         // static void toast(String)
static jmethodID g_showMods = nullptr;      // static void showMods()

static void* api_find_symbol_raw(const char* symbol);

static std::string g_gameVersion;
static std::string g_abi;
static bool g_shadowInit = false;
static void* g_gameHandle = nullptr;

static JNIEnv* get_env(bool* attached) {
    *attached = false;
    if (!g_vm) return nullptr;
    JNIEnv* env = nullptr;
    int r = g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (r == JNI_OK) return env;
    if (r == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, nullptr) == JNI_OK) {
            *attached = true;
            return env;
        }
    }
    return nullptr;
}

// Java: ZflipBridge.onMenuVisible(true) = "muestra el botón de respaldo (overlay)"
static void notify_fallback(bool show) {
    bool attached;
    JNIEnv* env = get_env(&attached);
    if (!env || !g_bridge || !g_onMenuVisible) return;
    env->CallStaticVoidMethod(g_bridge, g_onMenuVisible, static_cast<jboolean>(show));
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) g_vm->DetachCurrentThread();
}

static void notify_show_mods() {
    bool attached;
    JNIEnv* env = get_env(&attached);
    if (!env || !g_bridge || !g_showMods) return;
    env->CallStaticVoidMethod(g_bridge, g_showMods);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) g_vm->DetachCurrentThread();
}

// ---------------------------------------------------------------- botón dentro del menú principal
//
// Se crea con las funciones de cocos2d-x que exporta libcocos2dcpp.so (sin cabeceras del juego).
// El "callback" del botón es un puntero a método de CCObject: aquí declaramos un CCObject mínimo
// (sin vtable, nunca se instancia) con un método nuestro; el compilador genera el puntero a
// método con el formato correcto para cada arquitectura (arm64 / arm32).

// ---------------------------------------------------------------- protección contra cierres
// Las llamadas de interfaz que hacen los mods pasan por aquí: si una falla con SIGSEGV/SIGBUS
// se registra y se devuelve error en vez de cerrar el juego.
#include <csetjmp>
#include <csignal>
#include <ucontext.h>

static sigjmp_buf g_jb;
static volatile sig_atomic_t g_guardOn = 0;
static volatile int g_sig = 0;
static void* volatile g_addr = nullptr;
static struct sigaction g_old[32];

static void guard_handler(int sig, siginfo_t* info, void* ctx) {
    if (g_guardOn && (sig == SIGSEGV || sig == SIGBUS)) {
        g_sig = sig;
        g_addr = info ? info->si_addr : nullptr;
        g_guardOn = 0;
        siglongjmp(g_jb, 1);
    }
    // cierre no recuperable: dejar constancia en el registro antes de que el sistema cierre el juego
    {
        uintptr_t pc = 0;
#if defined(__aarch64__)
        if (ctx) pc = static_cast<uintptr_t>(static_cast<ucontext_t*>(ctx)->uc_mcontext.pc);
#elif defined(__arm__)
        if (ctx) pc = static_cast<uintptr_t>(static_cast<ucontext_t*>(ctx)->uc_mcontext.arm_pc);
#endif
        Dl_info di;
        memset(&di, 0, sizeof(di));
        const char* lib = "?";
        uintptr_t off = 0;
        if (pc && dladdr(reinterpret_cast<void*>(pc), &di) && di.dli_fname) {
            lib = di.dli_fname;
            off = pc - reinterpret_cast<uintptr_t>(di.dli_fbase);
        }
        zlog(ANDROID_LOG_ERROR, "CIERRE DEL JUEGO: señal %d, dirección %p, pc=%p (%s + 0x%lx)", sig,
             info ? info->si_addr : nullptr, reinterpret_cast<void*>(pc), lib, static_cast<unsigned long>(off));
    }
    if (sig < 32) {
        struct sigaction* old = &g_old[sig];
        if (old->sa_flags & SA_SIGINFO) {
            if (old->sa_sigaction) { old->sa_sigaction(sig, info, ctx); return; }
        } else if (old->sa_handler != SIG_DFL && old->sa_handler != SIG_IGN && old->sa_handler) {
            old->sa_handler(sig);
            return;
        }
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void install_guard() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = guard_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    const int sigs[] = {SIGSEGV, SIGBUS, SIGABRT, SIGILL, SIGFPE};
    for (int sg : sigs) sigaction(sg, &sa, &g_old[sg]);
}

#define GUARDED(NAME, FAIL, CALL)                                                          \
    do {                                                                                   \
        if (sigsetjmp(g_jb, 1)) {                                                          \
            LOGE("FALLO EVITADO en %s: señal %d, dirección %p", NAME, (int)g_sig, g_addr); \
            return FAIL;                                                                   \
        }                                                                                  \
        g_guardOn = 1;                                                                     \
        auto zr_ = CALL;                                                                   \
        g_guardOn = 0;                                                                     \
        return zr_;                                                                        \
    } while (0)


template <typename F>
static bool try_guard(const char* name, F f) {
    sigjmp_buf saved;
    memcpy(&saved, &g_jb, sizeof(saved));
    sig_atomic_t was = g_guardOn;
    volatile bool ok = true;
    if (sigsetjmp(g_jb, 1)) {
        LOGE("FALLO EVITADO en %s: señal %d, dirección %p", name, (int)g_sig, g_addr);
        ok = false;
    } else {
        g_guardOn = 1;
        f();
    }
    g_guardOn = was;
    memcpy(&g_jb, &saved, sizeof(saved));
    return ok;
}

namespace cocos2d {
class CCObject {
public:
    void zflipOnClick(CCObject* sender);
};
typedef void (CCObject::*SEL_MenuHandler)(CCObject*);
}

namespace {

struct Pt { float x, y; };
struct Sz { float w, h; };
struct Col4 { unsigned char r, g, b, a; };
struct Col3 { unsigned char r, g, b; };

void* g_lastParent = nullptr;   // última capa de interfaz (para medir la ventana)

struct Button {
    void (*cb)(void*);
    void* user;
    void* label;
};
std::unordered_map<void*, Button> g_buttons;   // botón (CCMenuItem*) -> acción

struct Cocos {
    void* (*getChildren)(void*) = nullptr;                // CCNode::getChildren
    unsigned (*arrayCount)(void*) = nullptr;              // CCArray::count
    void* (*arrayAt)(void*, unsigned) = nullptr;          // CCArray::objectAtIndex
    float (*getPosX)(void*) = nullptr;                    // CCNode::getPositionX
    float (*getPosY)(void*) = nullptr;                    // CCNode::getPositionY
    void (*setPosition)(void*, float, float) = nullptr;   // CCNode::setPosition(x, y)
    void (*addChild)(void*, void*) = nullptr;             // CCNode::addChild(child)
    void (*addChildZ)(void*, void*, int) = nullptr;       // CCNode::addChild(child, z)
    void (*setScale)(void*, float) = nullptr;             // CCNode::setScale
    void (*setVisible)(void*, bool) = nullptr;            // CCNode::setVisible
    const Sz* (*getContentSize)(void*) = nullptr;         // CCNode::getContentSize
    void* (*directorShared)() = nullptr;                  // CCDirector::sharedDirector
    Sz (*directorWinSize)(void*) = nullptr;               // CCDirector::getWinSize
    void* (*directorScheduler)(void*) = nullptr;          // CCDirector::getScheduler
    void (*schedSetTimeScale)(void*, float) = nullptr;    // CCScheduler::setTimeScale
    void* (*frameCacheShared)() = nullptr;                // CCSpriteFrameCache::sharedSpriteFrameCache
    void* (*frameByName)(void*, const char*) = nullptr;   // CCSpriteFrameCache::spriteFrameByName
    void* (*spriteByFrameName)(const char*) = nullptr;    // CCSprite::createWithSpriteFrameName
    void* (*labelCreate)(const char*, const char*) = nullptr; // CCLabelBMFont::create
    void (*labelSetString)(void*, const char*) = nullptr; // CCLabelBMFont::setString
    void (*labelSetColor)(void*, const Col3*) = nullptr;  // CCLabelBMFont::setColor
    void* (*layerColorCreate)(const Col4*, float, float) = nullptr; // CCLayerColor::create
    void* (*menuCreate)() = nullptr;                      // CCMenu::create
    void* (*itemExtraCreate)(void*, void*, void*, cocos2d::SEL_MenuHandler) = nullptr; // CCMenuItemSpriteExtra::create
    void* (*itemSpriteCreate)(void*, void*, void*, cocos2d::SEL_MenuHandler) = nullptr; // CCMenuItemSprite::create
    bool ready = false;
    bool tried = false;
};
Cocos C;

template <typename F>
bool resolve(F& out, const char* name, bool required = true) {
    void* p = api_find_symbol_raw(name);
    if (!p) {
        if (required) LOGW("símbolo NO encontrado: %s", name);
        else LOGD("símbolo opcional ausente: %s", name);
        return false;
    }
    out = reinterpret_cast<F>(p);
    return true;
}

bool resolve_cocos() {
    if (C.tried) return C.ready;
    C.tried = true;
    bool ok = true;
    ok &= resolve(C.getChildren, "_ZN7cocos2d6CCNode11getChildrenEv");
    ok &= resolve(C.arrayCount, "_ZNK7cocos2d7CCArray5countEv");
    ok &= resolve(C.arrayAt, "_ZN7cocos2d7CCArray13objectAtIndexEj");
    ok &= resolve(C.getPosX, "_ZN7cocos2d6CCNode12getPositionXEv");
    ok &= resolve(C.getPosY, "_ZN7cocos2d6CCNode12getPositionYEv");
    ok &= resolve(C.setPosition, "_ZN7cocos2d6CCNode11setPositionEff");
    ok &= resolve(C.addChild, "_ZN7cocos2d6CCNode8addChildEPS0_");
    ok &= resolve(C.directorShared, "_ZN7cocos2d10CCDirector14sharedDirectorEv");
    ok &= resolve(C.directorWinSize, "_ZN7cocos2d10CCDirector10getWinSizeEv");
    // opcionales (mejoran el aspecto o habilitan funciones extra)
    resolve(C.addChildZ, "_ZN7cocos2d6CCNode8addChildEPS0_i", false);
    resolve(C.setScale, "_ZN7cocos2d6CCNode8setScaleEf", false);
    resolve(C.setVisible, "_ZN7cocos2d6CCNode10setVisibleEb", false);
    resolve(C.getContentSize, "_ZNK7cocos2d6CCNode14getContentSizeEv", false);
    resolve(C.directorScheduler, "_ZN7cocos2d10CCDirector12getSchedulerEv", false);
    resolve(C.schedSetTimeScale, "_ZN7cocos2d11CCScheduler12setTimeScaleEf", false);
    resolve(C.frameCacheShared, "_ZN7cocos2d18CCSpriteFrameCache22sharedSpriteFrameCacheEv", false);
    resolve(C.frameByName, "_ZN7cocos2d18CCSpriteFrameCache17spriteFrameByNameEPKc", false);
    resolve(C.spriteByFrameName, "_ZN7cocos2d8CCSprite25createWithSpriteFrameNameEPKc", false);
    resolve(C.labelCreate, "_ZN7cocos2d13CCLabelBMFont6createEPKcS2_", false);
    resolve(C.labelSetString, "_ZN7cocos2d13CCLabelBMFont9setStringEPKc", false);
    resolve(C.labelSetColor, "_ZN7cocos2d13CCLabelBMFont8setColorERKNS_10_ccColor3BE", false);
    resolve(C.layerColorCreate, "_ZN7cocos2d12CCLayerColor6createERKNS_10_ccColor4BEff", false);
    resolve(C.menuCreate, "_ZN7cocos2d6CCMenu6createEv", false);
    bool hasExtra = resolve(C.itemExtraCreate,
        "_ZN21CCMenuItemSpriteExtra6createEPN7cocos2d6CCNodeES2_PNS0_8CCObjectEMS3_FvS4_E", false);
    bool hasSprite = resolve(C.itemSpriteCreate,
        "_ZN7cocos2d16CCMenuItemSprite6createEPNS_6CCNodeES2_PNS_8CCObjectEMS3_FvS4_E", false);
    if (!hasExtra && !hasSprite) LOGW("no hay forma de crear botones (CCMenuItemSprite*)");
    ok &= (hasExtra || hasSprite);
    C.ready = ok;
    LOGI("símbolos de cocos2d resueltos: %s", ok ? "OK" : "FALTAN OBLIGATORIOS");
    return ok;
}

// Tamaño de la ventana de cocos2d. En GD 2.2091 CCDirector::getWinSize cierra el juego, así que se
// prueba por orden: director (protegido), tamaño del nodo dado, y por último 569x320.
Sz window_size(void* node) {
    static bool dirBroken = false;
    static Sz cached{0, 0};
    if (cached.w > 0) return cached;
    Sz out{0, 0};
    if (!dirBroken) {
        bool ok = try_guard("CCDirector::getWinSize", [&] { out = C.directorWinSize(C.directorShared()); });
        if (!ok || !(out.w > 0 && out.h > 0)) { dirBroken = true; out = Sz{0, 0}; }
    }
    if (out.w <= 0 && node && C.getContentSize) {
        try_guard("CCNode::getContentSize", [&] {
            const Sz* sz = C.getContentSize(node);
            if (sz) out = *sz;
        });
        if (out.w > 0) LOGI("tamaño de ventana tomado del nodo: %.1f x %.1f", out.w, out.h);
    }
    if (!(out.w > 0 && out.h > 0)) {
        out = Sz{569.f, 320.f};
        LOGW("tamaño de ventana por defecto: 569 x 320");
        return out;   // sin cachear: se reintentará con otro nodo
    }
    cached = out;
    return out;
}

void addTo(void* parent, void* child, int z) {
    if (C.addChildZ) C.addChildZ(parent, child, z);
    else C.addChild(parent, child);
}

void show_mods_cb(void*) { notify_show_mods(); }

// Crea un botón (texto sobre sprite opcional) y lo registra. normal = nodo ya construido.
void* make_item(void* normal, void* target, void (*cb)(void*), void* user, void* label) {
    cocos2d::SEL_MenuHandler handler = &cocos2d::CCObject::zflipOnClick;
    void* item = C.itemExtraCreate ? C.itemExtraCreate(normal, nullptr, target, handler)
                                   : C.itemSpriteCreate ? C.itemSpriteCreate(normal, nullptr, target, handler)
                                                        : nullptr;
    if (item) g_buttons[item] = Button{cb, user, label};
    return item;
}

void dump_tree(void* node, int depth, int maxDepth) {
    void* kids = C.getChildren(node);
    unsigned n = kids ? C.arrayCount(kids) : 0;
    for (unsigned i = 0; i < n; i++) {
        void* c = C.arrayAt(kids, i);
        if (!c) continue;
        void* ck = C.getChildren(c);
        unsigned cn = ck ? C.arrayCount(ck) : 0;
        LOGD("%*s[%u] %p pos=(%.1f, %.1f) hijos=%u", depth * 2, "", i, c, C.getPosX(c), C.getPosY(c), cn);
        if (depth + 1 < maxDepth && cn) dump_tree(c, depth + 1, maxDepth);
    }
}

// Crea el botón «MODS» y lo añade al menú inferior del MenuLayer (junto a logros, opciones,
// estadísticas). Si no se encuentra ese menú, crea uno propio en una esquina.
bool add_zflip_button(void* menuLayer) {
    if (!menuLayer) { LOGE("MenuLayer nulo"); return false; }
    if (!resolve_cocos()) return false;

    Sz ws = window_size(menuLayer);
    LOGI("ventana cocos: %.1f x %.1f", ws.w, ws.h);
    if (!(ws.w > 0 && ws.h > 0)) { LOGE("tamaño de ventana inválido"); return false; }

    void* layerChildren = C.getChildren(menuLayer);
    if (!layerChildren) { LOGE("MenuLayer sin hijos"); return false; }
    unsigned n = C.arrayCount(layerChildren);
    LOGI("MenuLayer %p tiene %u hijos", menuLayer, n);
    dump_tree(menuLayer, 0, 2);

    // 1) aspecto del botón: icono de opciones con «MODS» encima (si existe), o solo texto
    void* normal = nullptr;
    void* label = C.labelCreate ? C.labelCreate("MODS", "bigFont.fnt") : nullptr;
    const char* frame = "GJ_optionsBtn_001.png";
    bool haveFrame = C.frameCacheShared && C.frameByName && C.spriteByFrameName &&
                     C.frameByName(C.frameCacheShared(), frame);
    LOGI("sprite %s: %s, etiqueta: %s", frame, haveFrame ? "existe" : "no existe", label ? "ok" : "no");
    if (haveFrame) normal = C.spriteByFrameName(frame);
    if (normal && label) {
        if (C.setScale) C.setScale(label, 0.38f);
        if (C.getContentSize) {
            const Sz* size = C.getContentSize(normal);
            if (size) C.setPosition(label, size->w / 2, size->h / 2);
        }
        C.addChild(normal, label);
    } else if (!normal) {
        normal = label;
        if (normal && C.setScale) C.setScale(normal, 0.7f);
    }
    if (!normal) { LOGE("no se pudo crear el aspecto del botón"); return false; }

    void* item = make_item(normal, menuLayer, show_mods_cb, nullptr, label);
    if (!item) { LOGE("no se pudo crear el CCMenuItem"); return false; }

    // 2) localizar el menú inferior: una fila horizontal de >=3 botones en la parte baja
    void* bottom = nullptr;
    unsigned bottomCount = 0;
    float rowY = 0, minX = 0, maxX = 0;
    for (unsigned i = 0; i < n; i++) {
        void* child = C.arrayAt(layerChildren, i);
        if (!child) continue;
        void* kids = C.getChildren(child);
        unsigned k = kids ? C.arrayCount(kids) : 0;
        if (k < 3) continue;
        float cx = C.getPosX(child), cy = C.getPosY(child);
        float y0 = 0, mn = 1e9f, mx = -1e9f;
        bool row = true;
        for (unsigned j = 0; j < k; j++) {
            void* it = C.arrayAt(kids, j);
            if (!it) { row = false; break; }
            float iy = C.getPosY(it), ix = C.getPosX(it);
            if (j == 0) y0 = iy;
            else if (std::fabs(iy - y0) > 2.f) { row = false; break; }
            if (ix < mn) mn = ix;
            if (ix > mx) mx = ix;
        }
        float worldY = cy + y0;
        float worldMid = cx + (mn + mx) / 2;
        LOGD("candidato %p: hijos=%u fila=%d worldY=%.1f centroX=%.1f", child, k, row, worldY, worldMid);
        if (row && worldY < ws.h * 0.35f && std::fabs(worldMid - ws.w / 2) < ws.w * 0.25f && k > bottomCount) {
            bottom = child; bottomCount = k; rowY = y0; minX = mn; maxX = mx;
        }
    }

    if (bottom) {
        float spacing = (maxX - minX) / static_cast<float>(bottomCount - 1);
        LOGI("menú inferior: %p (%u botones, separación %.1f, y=%.1f)", bottom, bottomCount, spacing, rowY);
        C.setPosition(item, maxX + spacing, rowY);
        C.addChild(bottom, item);
        float mx = C.getPosX(bottom), my = C.getPosY(bottom);
        C.setPosition(bottom, mx - spacing / 2, my);   // re-centrar la fila
        LOGI("botón MODS añadido al menú inferior en (%.1f, %.1f)", maxX + spacing, rowY);
        return true;
    }

    // 3) respaldo nativo: menú propio
    LOGW("no se encontró el menú inferior; creo un menú propio");
    if (!C.menuCreate) { LOGE("CCMenu::create no disponible"); return false; }
    void* menu = C.menuCreate();
    if (!menu) { LOGE("CCMenu::create devolvió nulo"); return false; }
    C.setPosition(menu, 0, 0);
    C.setPosition(item, ws.w - 40.f, 40.f);
    C.addChild(menu, item);
    addTo(menuLayer, menu, 50);
    LOGI("botón MODS añadido en menú propio (%.1f, 40)", ws.w - 40.f);
    return true;
}

} // namespace

void cocos2d::CCObject::zflipOnClick(cocos2d::CCObject* sender) {
    auto it = g_buttons.find(sender);
    if (it == g_buttons.end()) {
        LOGW("clic en un botón desconocido %p", static_cast<void*>(sender));
        return;
    }
    LOGD("clic en botón %p", static_cast<void*>(sender));
    if (it->second.cb) it->second.cb(it->second.user);
}

// ---------------------------------------------------------------- API de interfaz para mods
namespace {

void ui_win_size_impl(float* w, float* h) {
    if (!resolve_cocos()) { if (w) *w = 0; if (h) *h = 0; return; }
    Sz s = window_size(g_lastParent);
    if (w) *w = s.w;
    if (h) *h = s.h;
}

void* ui_rect_impl(void* parent, float x, float y, float w, float h,
              uint8_t r, uint8_t g, uint8_t b, uint8_t a, int z) {
    g_lastParent = parent;
    if (!parent || !resolve_cocos() || !C.layerColorCreate) return nullptr;
    Col4 c{r, g, b, a};
    LOGD("ui_rect: CCLayerColor::create(%.0f x %.0f)", w, h);
    void* node = C.layerColorCreate(&c, w, h);
    LOGD("ui_rect: nodo=%p", node);
    if (!node) return nullptr;
    C.setPosition(node, x, y);
    addTo(parent, node, z);
    return node;
}

void* ui_label_impl(void* parent, const char* text, float scale, float x, float y, int z) {
    g_lastParent = parent;
    if (!parent || !resolve_cocos() || !C.labelCreate) return nullptr;
    LOGD("ui_label: crear \"%s\"", text ? text : "");
    void* node = C.labelCreate(text ? text : "", "bigFont.fnt");
    LOGD("ui_label: nodo=%p", node);
    if (!node) return nullptr;
    if (C.setScale) C.setScale(node, scale);
    C.setPosition(node, x, y);
    addTo(parent, node, z);
    LOGD("ui_label: añadido");
    return node;
}

void* ui_menu_impl(void* parent, int z) {
    g_lastParent = parent;
    if (!parent || !resolve_cocos() || !C.menuCreate) return nullptr;
    LOGD("ui_menu: CCMenu::create");
    void* menu = C.menuCreate();
    LOGD("ui_menu: menu=%p", menu);
    if (!menu) return nullptr;
    C.setPosition(menu, 0, 0);
    addTo(parent, menu, z);
    LOGD("ui_menu: añadido");
    return menu;
}

void* ui_button_impl(void* menu, const char* text, float scale, float x, float y,
                void (*cb)(void*), void* user) {
    if (!menu || !resolve_cocos() || !C.labelCreate) return nullptr;
    void* label = C.labelCreate(text ? text : "", "bigFont.fnt");
    if (!label) return nullptr;
    if (C.setScale) C.setScale(label, scale);
    LOGD("ui_button: \"%s\" etiqueta=%p, creando item", text ? text : "", label);
    void* item = make_item(label, menu, cb, user, label);
    LOGD("ui_button: item=%p", item);
    if (!item) return nullptr;
    C.setPosition(item, x, y);
    C.addChild(menu, item);
    LOGD("ui_button: añadido");
    return item;
}

void* label_of(void* h) {
    auto it = g_buttons.find(h);
    return it != g_buttons.end() ? it->second.label : h;
}

void ui_set_text_impl(void* h, const char* text) {
    if (!h || !text || !C.labelSetString) return;
    C.labelSetString(label_of(h), text);
}

void ui_set_color_impl(void* h, uint8_t r, uint8_t g, uint8_t b) {
    if (!h || !C.labelSetColor) return;
    Col3 c{r, g, b};
    C.labelSetColor(label_of(h), &c);
}

void ui_set_visible_impl(void* node, int visible) {
    if (node && C.setVisible) C.setVisible(node, visible != 0);
}

int api_set_time_scale_impl(float scale) {
    if (!resolve_cocos() || !C.directorScheduler || !C.schedSetTimeScale) return -1;
    void* sch = C.directorScheduler(C.directorShared());
    if (!sch) return -1;
    C.schedSetTimeScale(sch, scale);
    return 0;
}

} // namespace

static bool (*orig_MenuLayer_init)(void*) = nullptr;
static bool hook_MenuLayer_init(void* self) {
    LOGI("MenuLayer::init: entrando (%p)", self);
    bool r = orig_MenuLayer_init(self);
    volatile bool ok = false;
    LOGI("MenuLayer::init ejecutado (resultado %d)", r);
    if (r) {
        try_guard("add_zflip_button", [&] { ok = add_zflip_button(self); });
        if (!ok) LOGE("add_zflip_button no terminó correctamente");
    }
    LOGI("botón nativo: %s", ok ? "creado" : "FALLÓ -> botón de respaldo");
    // si no se pudo crear el botón nativo, se muestra el botón de respaldo de Android
    notify_fallback(!ok);
    return r;
}

static bool install_menu_hooks() {
    void* stub = shadowhook_hook_sym_name(GAME_LIB, "_ZN9MenuLayer4initEv",
                                          reinterpret_cast<void*>(hook_MenuLayer_init),
                                          reinterpret_cast<void**>(&orig_MenuLayer_init));
    if (!stub) {
        LOGE("no se pudo enganchar MenuLayer::init");
        return false;
    }
    return true;
}


static void g_ui_win_size(float* w, float* h) { ui_win_size_impl(w, h); }
static void* g_ui_rect(void* p, float x, float y, float w, float h, uint8_t r, uint8_t g, uint8_t b, uint8_t a, int z) {
    GUARDED("ui_rect", nullptr, ui_rect_impl(p, x, y, w, h, r, g, b, a, z));
}
static void* g_ui_label(void* p, const char* t, float s, float x, float y, int z) {
    GUARDED("ui_label", nullptr, ui_label_impl(p, t, s, x, y, z));
}
static void* g_ui_menu(void* p, int z) { GUARDED("ui_menu", nullptr, ui_menu_impl(p, z)); }
static void* g_ui_button(void* m, const char* t, float s, float x, float y, void (*cb)(void*), void* u) {
    GUARDED("ui_button", nullptr, ui_button_impl(m, t, s, x, y, cb, u));
}
static void g_ui_set_text(void* h, const char* t) {
    if (sigsetjmp(g_jb, 1)) { LOGE("FALLO EVITADO en ui_set_text: señal %d, dirección %p", (int)g_sig, g_addr); return; }
    g_guardOn = 1; ui_set_text_impl(h, t); g_guardOn = 0;
}
static void g_ui_set_color(void* h, uint8_t r, uint8_t g, uint8_t b) {
    if (sigsetjmp(g_jb, 1)) { LOGE("FALLO EVITADO en ui_set_color: señal %d, dirección %p", (int)g_sig, g_addr); return; }
    g_guardOn = 1; ui_set_color_impl(h, r, g, b); g_guardOn = 0;
}
static void g_ui_set_visible(void* n, int v) {
    if (sigsetjmp(g_jb, 1)) { LOGE("FALLO EVITADO en ui_set_visible: señal %d, dirección %p", (int)g_sig, g_addr); return; }
    g_guardOn = 1; ui_set_visible_impl(n, v); g_guardOn = 0;
}
static int g_set_time_scale(float f) { GUARDED("set_time_scale", -1, api_set_time_scale_impl(f)); }

// ---------------------------------------------------------------- API para mods

static void* api_find_symbol_raw(const char* symbol) {
    if (!g_shadowInit || !symbol) return nullptr;
    if (!g_gameHandle) g_gameHandle = shadowhook_dlopen(GAME_LIB);
    if (!g_gameHandle) return nullptr;
    return shadowhook_dlsym(g_gameHandle, symbol);
}

static void* api_find_symbol(const char* symbol) { return api_find_symbol_raw(symbol); }

static int api_hook_symbol(const char* symbol, void* detour, void** original) {
    if (!g_shadowInit || !symbol || !detour) return -1;
    void* stub = shadowhook_hook_sym_name(GAME_LIB, symbol, detour, original);
    return stub ? 0 : -1;
}

static int api_hook_address(void* address, void* detour, void** original) {
    if (!g_shadowInit || !address || !detour) return -1;
    void* stub = shadowhook_hook_sym_addr(address, detour, original);
    return stub ? 0 : -1;
}

struct ModContext {
    std::string id;
    std::string dataDir;
    std::string tag;
    ZflipApi api;
};

// Los mods guardan el puntero, así que los contextos viven hasta que se cierra el proceso.
static void api_log(int level, const char* message) {
    zlog_write(level, "ZFlip/mod", message ? message : "(null)");
}

static void api_toast(const char* message) {
    if (!message) return;
    bool attached;
    JNIEnv* env = get_env(&attached);
    if (!env || !g_bridge || !g_toast) return;
    jstring s = env->NewStringUTF(message);
    env->CallStaticVoidMethod(g_bridge, g_toast, s);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(s);
    if (attached) g_vm->DetachCurrentThread();
}

// ---------------------------------------------------------------- JNI

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;

    jclass local = env->FindClass("com/zflip/launcher/ZflipBridge");
    if (local) {
        g_bridge = static_cast<jclass>(env->NewGlobalRef(local));
        g_onMenuVisible = env->GetStaticMethodID(g_bridge, "onMenuVisible", "(Z)V");
        g_toast = env->GetStaticMethodID(g_bridge, "toast", "(Ljava/lang/String;)V");
        g_showMods = env->GetStaticMethodID(g_bridge, "showMods", "()V");
        env->DeleteLocalRef(local);
    } else {
        env->ExceptionClear();
        LOGW("ZflipBridge no encontrada");
    }
    return JNI_VERSION_1_6;
}

// Devuelve bit 0 = hooks del menú instalados.
extern "C" JNIEXPORT jint JNICALL Java_com_zflip_launcher_ZflipNative_nativeInit(
        JNIEnv* env, jobject, jstring gameVersion, jstring abi, jstring logPath) {
    if (logPath) {
        const char* lp = env->GetStringUTFChars(logPath, nullptr);
        g_logPath = lp;
        env->ReleaseStringUTFChars(logPath, lp);
    }
    const char* gv = env->GetStringUTFChars(gameVersion, nullptr);
    const char* ab = env->GetStringUTFChars(abi, nullptr);
    g_gameVersion = gv;
    g_abi = ab;
    env->ReleaseStringUTFChars(gameVersion, gv);
    env->ReleaseStringUTFChars(abi, ab);
    LOGI("motor ZFlip nativo iniciado (GD %s, %s, %zu bits)", g_gameVersion.c_str(), g_abi.c_str(), sizeof(void*) * 8);

    int rc = shadowhook_init(SHADOWHOOK_MODE_SHARED, false);
    if (rc != 0) {
        LOGE("shadowhook_init falló: %d", rc);
        return 0;
    }
    g_shadowInit = true;
    install_guard();
    bool ok = install_menu_hooks();
    LOGI("hook de MenuLayer::init: %s", ok ? "instalado" : "FALLÓ");
    return ok ? 1 : 0;
}

// Devuelve null si el mod se cargó bien, o un mensaje de error.
extern "C" JNIEXPORT jstring JNICALL Java_com_zflip_launcher_ZflipNative_nativeLoadMod(
        JNIEnv* env, jobject, jstring libPath, jstring modId, jstring dataDir) {
    const char* path = env->GetStringUTFChars(libPath, nullptr);
    const char* id = env->GetStringUTFChars(modId, nullptr);
    const char* dd = env->GetStringUTFChars(dataDir, nullptr);

    std::string error;
    void* handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!handle) {
        const char* e = dlerror();
        error = std::string("dlopen falló: ") + (e ? e : "?");
    } else {
        auto entry = reinterpret_cast<zflip_main_fn>(dlsym(handle, "zflip_main"));
        if (!entry) {
            error = "el mod no exporta zflip_main";
        } else {
            auto* ctx = new ModContext();
            ctx->id = id;
            ctx->dataDir = dd;
            std::memset(&ctx->api, 0, sizeof(ctx->api));
            ctx->api.struct_size = sizeof(ZflipApi);
            ctx->api.api_version = ZFLIP_API_VERSION;
            ctx->api.game_version = g_gameVersion.c_str();
            ctx->api.abi = g_abi.c_str();
            ctx->api.mod_id = ctx->id.c_str();
            ctx->api.data_dir = ctx->dataDir.c_str();
            ctx->api.java_vm = g_vm;
            ctx->api.find_symbol = api_find_symbol;
            ctx->api.hook_symbol = api_hook_symbol;
            ctx->api.hook_address = api_hook_address;
            ctx->api.log = api_log;
            ctx->api.toast = api_toast;
            ctx->api.ui_win_size = g_ui_win_size;
            ctx->api.ui_rect = g_ui_rect;
            ctx->api.ui_label = g_ui_label;
            ctx->api.ui_menu = g_ui_menu;
            ctx->api.ui_button = g_ui_button;
            ctx->api.ui_set_text = g_ui_set_text;
            ctx->api.ui_set_color = g_ui_set_color;
            ctx->api.ui_set_visible = g_ui_set_visible;
            ctx->api.set_time_scale = g_set_time_scale;

            LOGI("cargando mod %s", id);
            int r = entry(&ctx->api);
            if (r != 0) error = "zflip_main devolvió " + std::to_string(r);
        }
    }

    env->ReleaseStringUTFChars(libPath, path);
    env->ReleaseStringUTFChars(modId, id);
    env->ReleaseStringUTFChars(dataDir, dd);

    if (error.empty()) return nullptr;
    LOGE("mod %s: %s", id, error.c_str());
    return env->NewStringUTF(error.c_str());
}
