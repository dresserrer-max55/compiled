/*
 * ZFlip mod API (versión 4)
 *
 * Un mod .zflip contiene una librería nativa (.so) que exporta:
 *
 *     extern "C" int zflip_main(const ZflipApi* api);
 *
 * El loader la llama una vez, después de cargar Geometry Dash y antes de que
 * arranque el menú principal. Devuelve 0 si todo va bien.
 *
 * Los mods NO dependen de Geode ni de ningún otro framework: los símbolos del
 * juego se resuelven por nombre (los nombres C++ "mangled" que exporta
 * libcocos2dcpp.so) y se enganchan con api->hook_symbol.
 */
#ifndef ZFLIP_H
#define ZFLIP_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ZFLIP_API_VERSION 4

#define ZFLIP_LOG_DEBUG 3
#define ZFLIP_LOG_INFO  4
#define ZFLIP_LOG_WARN  5
#define ZFLIP_LOG_ERROR 6

typedef struct ZflipApi {
    /* tamaño de esta estructura; permite añadir campos al final sin romper mods antiguos */
    uint32_t struct_size;
    uint32_t api_version;

    /* versión de Geometry Dash instalada, p. ej. "2.2091" */
    const char* game_version;
    /* "arm64-v8a" o "armeabi-v7a" */
    const char* abi;
    /* id del mod (el del manifest.json) */
    const char* mod_id;
    /* carpeta privada del mod donde puede guardar datos (ya existe) */
    const char* data_dir;
    /* JavaVM* del proceso (para llamar a Java por JNI) */
    void* java_vm;

    /* Busca un símbolo exportado por libcocos2dcpp.so. NULL si no existe. */
    void* (*find_symbol)(const char* symbol);

    /*
     * Engancha una función del juego por nombre de símbolo.
     * detour = tu función; *original recibe un puntero para llamar a la original.
     * Devuelve 0 si ok, distinto de 0 si falla.
     */
    int (*hook_symbol)(const char* symbol, void* detour, void** original);

    /* Igual, pero por dirección (p. ej. obtenida con find_symbol). */
    int (*hook_address)(void* address, void* detour, void** original);

    /* Escribe en logcat con la etiqueta "ZFlip/<mod_id>". */
    void (*log)(int level, const char* message);

    /* Muestra un aviso (Toast) en pantalla. */
    void (*toast)(const char* message);

    /* ------------------------------------------------------------------
     * API v2 — ayudas de interfaz (cocos2d-x). Cualquier puntero puede ser NULL si el
     * juego no exporta lo necesario: comprueba api->struct_size >= sizeof(ZflipApi) y
     * que el puntero no sea NULL antes de usarlo.
     * Los "nodos" son punteros opacos a cocos2d::CCNode del juego.
     * ------------------------------------------------------------------ */

    /* Tamaño de la ventana de cocos2d (en puntos). */
    void (*ui_win_size)(float* w, float* h);

    /* Rectángulo de color (CCLayerColor) con esquina inferior izquierda en (x,y). */
    void* (*ui_rect)(void* parent, float x, float y, float w, float h,
                     uint8_t r, uint8_t g, uint8_t b, uint8_t a, int z);

    /* Texto (fuente bigFont.fnt). Devuelve el nodo (sirve para ui_set_text / ui_set_color). */
    void* (*ui_label)(void* parent, const char* text, float scale, float x, float y, int z);

    /* Crea un CCMenu vacío (en 0,0) dentro de parent; ahí van los botones. */
    void* (*ui_menu)(void* parent, int z);

    /* Botón de texto dentro de un menú. cb(user) se llama al pulsarlo. Devuelve el botón. */
    void* (*ui_button)(void* menu, const char* text, float scale, float x, float y,
                       void (*cb)(void* user), void* user);

    /* Cambia el texto de una etiqueta o de un botón creado con ui_button. */
    void (*ui_set_text)(void* labelOrButton, const char* text);

    /* Color del texto de una etiqueta o botón (0-255). */
    void (*ui_set_color)(void* labelOrButton, uint8_t r, uint8_t g, uint8_t b);

    void (*ui_set_visible)(void* node, int visible);

    /* Velocidad global del juego (1.0 = normal). Devuelve 0 si ok, -1 si no está disponible. */
    int (*set_time_scale)(float scale);

    /* ------------------------------------------------------------------
     * API v3 — eventos. ZFlip engancha MenuLayer::init y LoadingLayer::init UNA sola vez y avisa
     * a los mods; NO enganches esas dos funciones tú mismo (el segundo hook falla o se salta al
     * primero). cb(layer) se llama en el hilo del juego, después de que la función original
     * termine. Devuelven 0 si ok.
     * ------------------------------------------------------------------ */
    int (*on_loading_layer)(void (*cb)(void* layer));
    int (*on_menu_layer)(void (*cb)(void* layer));

    /* ------------------------------------------------------------------
     * API v4 — menú de pausa. ZFlip también engancha PauseLayer::customSetup (cb(layer) tras
     * crearse la interfaz de pausa) y permite ajustar la prioridad táctil de un menú: la capa
     * de pausa captura los toques, así que un menú propio dentro de ella necesita prioridad
     * más alta (número más negativo, p. ej. -600).
     * ------------------------------------------------------------------ */
    int (*on_pause_layer)(void (*cb)(void* layer));
    void (*ui_menu_priority)(void* menu, int priority);
} ZflipApi;

typedef int (*zflip_main_fn)(const ZflipApi* api);

#ifdef __cplusplus
}
#endif

#endif /* ZFLIP_H */
