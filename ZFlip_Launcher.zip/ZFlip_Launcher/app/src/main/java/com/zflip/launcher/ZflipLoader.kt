package com.zflip.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import com.zflip.launcher.utils.GamePackageUtils
import com.zflip.launcher.utils.LaunchUtils
import java.io.File
import java.util.zip.ZipFile

/** Estado de cada mod tras el último arranque del juego. */
enum class ModState { LOADED, DISABLED, INCOMPATIBLE, ERROR, CRASHED }

data class ModResult(val state: ModState, val detail: String)

object ZflipLoader {
    private const val TAG = "ZFlipLoader"
    private const val PREFS = "zflip"
    private const val KEY_DISABLED = "disabled"

    /** Resultado del último arranque (id -> estado). */
    @Volatile
    var lastResults: Map<String, ModResult> = emptyMap()
        private set

    /** true si los hooks del menú principal funcionaron (el botón se muestra solo allí). */
    @Volatile
    var menuHooksOk = false
        private set

    fun listMods(context: Context): List<ZflipMod> {
        val gameVersion = GamePackageUtils.getUnifiedVersionNameOrNull(context.packageManager)
        val abi = LaunchUtils.applicationArchitecture
        return LaunchUtils.getModsDirectory(context)
            .listFiles { f -> f.isFile && f.name.endsWith(ZflipMod.EXTENSION, true) }
            ?.sortedBy { it.name.lowercase() }
            ?.map { ZflipMod.parse(it, gameVersion, abi) }
            ?: emptyList()
    }

    fun isEnabled(context: Context, id: String): Boolean =
        !disabledSet(context).contains(id)

    fun setEnabled(context: Context, id: String, enabled: Boolean) {
        val set = disabledSet(context).toMutableSet()
        if (enabled) set.remove(id) else set.add(id)
        prefs(context).edit().putStringSet(KEY_DISABLED, set).apply()
    }

    fun alwaysFloating(context: Context): Boolean = prefs(context).getBoolean("always_floating", false)
    fun setAlwaysFloating(context: Context, v: Boolean) = prefs(context).edit().putBoolean("always_floating", v).apply()

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun disabledSet(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_DISABLED, emptySet()) ?: emptySet()

    /**
     * Carga el motor y todos los mods compatibles y activados.
     * Debe llamarse después de cargar libcocos2dcpp.so y antes de que arranque el menú.
     * Nunca lanza: los fallos de un mod quedan en lastResults y no afectan al juego.
     */
    @SuppressLint("UnsafeDynamicallyLoadedCode")
    fun loadAll(context: Context, gameVersion: String) {
        ZLog.i(TAG, "cargando mods para GD $gameVersion")
        val results = linkedMapOf<String, ModResult>()
        lastResults = results

        val abi = LaunchUtils.applicationArchitecture

        // Un mod que tumbó el proceso en el arranque anterior queda desactivado.
        val guard = File(context.filesDir, "zflip_loading.txt")
        if (guard.exists()) {
            val culprit = guard.readText().trim()
            if (culprit.isNotEmpty()) {
                setEnabled(context, culprit, false)
                results[culprit] = ModResult(
                    ModState.CRASHED, "cerró el juego al cargarse; se desactivó automáticamente"
                )
            }
            guard.delete()
        }

        try {
            ZflipNative.loadLibrary()
            val flags = ZflipNative.nativeInit(gameVersion, abi, ZLog.logFile(context).path)
            menuHooksOk = (flags and 1) != 0
            ZLog.i(TAG, "motor iniciado; hooks del menú: $menuHooksOk")
        } catch (t: Throwable) {
            ZLog.e(TAG, "no se pudo iniciar el motor de mods: ${Log.getStackTraceString(t)}")
            return
        }

        val cacheRoot = File(context.codeCacheDir, "zflip").apply {
            deleteRecursively()
            mkdirs()
        }

        for (mod in listMods(context)) {
            when {
                results[mod.id]?.state == ModState.CRASHED -> continue
                !mod.compatible -> {
                    results[mod.id] = ModResult(ModState.INCOMPATIBLE, mod.reason)
                    ZLog.w(TAG, "mod ${mod.id} incompatible: ${mod.reason}")
                }
                !isEnabled(context, mod.id) ->
                    results[mod.id] = ModResult(ModState.DISABLED, "desactivado")
                else -> {
                    try {
                        val libFile = extractLib(mod, abi, File(cacheRoot, mod.id))
                        guard.writeText(mod.id)
                        val dataDir = LaunchUtils.getModDataDirectory(context, mod.id)
                        val err = ZflipNative.nativeLoadMod(libFile.path, mod.id, dataDir.path)
                        guard.delete()
                        results[mod.id] = if (err == null) ModResult(ModState.LOADED, "cargado")
                        else ModResult(ModState.ERROR, err)
                        ZLog.i(TAG, "mod ${mod.id}: ${results[mod.id]?.state} ${err ?: ""}")
                    } catch (t: Throwable) {
                        guard.delete()
                        ZLog.e(TAG, "error cargando ${mod.id}: ${Log.getStackTraceString(t)}")
                        results[mod.id] = ModResult(ModState.ERROR, t.message ?: t.javaClass.simpleName)
                    }
                }
            }
        }
        guard.delete()
    }

    private fun extractLib(mod: ZflipMod, abi: String, dir: File): File {
        dir.mkdirs()
        val out = File(dir, "lib${mod.id}.so")
        ZipFile(mod.file).use { zip ->
            val entry = zip.getEntry(mod.libEntry(abi))
                ?: throw IllegalStateException("falta ${mod.libEntry(abi)}")
            zip.getInputStream(entry).use { input ->
                out.outputStream().use { input.copyTo(it) }
            }
        }
        // Android 14+: el código cargado dinámicamente debe ser de solo lectura
        out.setReadOnly()
        return out
    }
}
