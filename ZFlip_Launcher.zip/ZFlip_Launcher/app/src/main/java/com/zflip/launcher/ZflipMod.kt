package com.zflip.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

/**
 * Un mod .zflip es un zip con:
 *   manifest.json
 *   lib/arm64-v8a/<lib>.so
 *   lib/armeabi-v7a/<lib>.so
 *
 * manifest.json:
 *   { "id": "hello", "name": "Hello", "version": "1.0.0", "author": "yo",
 *     "description": "...", "gd": ["2.209", "2.2091"],    // o "*" para cualquier versión
 *     "lib": "mod.so" }                         // opcional, por defecto "mod.so"
 */
data class ZflipMod(
    val file: File,
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val gdVersions: List<String>,
    val libName: String,
    val compatible: Boolean,
    /** Explicación legible: por qué es (o no) compatible. */
    val reason: String
) {
    fun libEntry(abi: String) = "lib/$abi/$libName"

    companion object {
        const val EXTENSION = ".zflip"

        fun parse(file: File, gameVersion: String?, abi: String): ZflipMod {
            val fallbackId = file.nameWithoutExtension
            fun broken(why: String) = ZflipMod(
                file, fallbackId, fallbackId, "", "", "", emptyList(), "mod.so", false, why
            )

            try {
                ZipFile(file).use { zip ->
                    val entry = zip.getEntry("manifest.json") ?: return broken("no contiene manifest.json")
                    val text = zip.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
                    val j = JSONObject(text)

                    val id = j.optString("id", "").ifEmpty { fallbackId }
                        .replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val name = j.optString("name", id)
                    val version = j.optString("version", "")
                    val author = j.optString("author", "")
                    val description = j.optString("description", "")
                    val libName = j.optString("lib", "mod.so")

                    val gd = mutableListOf<String>()
                    when (val g = j.opt("gd")) {
                        is String -> gd.add(g)
                        is JSONArray -> for (i in 0 until g.length()) gd.add(g.getString(i))
                    }

                    val hasLib = zip.getEntry("lib/$abi/$libName") != null
                    val gdOk = gd.contains("*") || (gameVersion != null && gd.contains(gameVersion))

                    val (ok, why) = when {
                        gd.isEmpty() -> false to "el manifest no declara versiones de GD"
                        gameVersion == null && !gd.contains("*") -> false to "Geometry Dash no está instalado"
                        !gdOk -> false to "requiere GD ${gd.joinToString(" / ")}, tienes $gameVersion"
                        !hasLib -> false to "no incluye librería para $abi"
                        gd.contains("*") -> true to "compatible con cualquier versión de GD"
                        else -> true to "compatible con GD $gameVersion"
                    }
                    return ZflipMod(file, id, name, version, author, description, gd, libName, ok, why)
                }
            } catch (_: Exception) {
                return broken("archivo .zflip dañado")
            }
        }
    }
}
