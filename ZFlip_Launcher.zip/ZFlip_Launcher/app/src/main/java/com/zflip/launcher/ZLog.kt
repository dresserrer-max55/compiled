package com.zflip.launcher

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registro de la app: se escribe en un archivo (el código nativo escribe en el mismo) y en logcat.
 * La pantalla «Registros» lo muestra, y se puede copiar o compartir.
 */
object ZLog {
    private const val MAX_BYTES = 400_000L
    private const val KEEP_BYTES = 150_000

    @Volatile
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val lock = Any()

    fun logFile(context: Context): File =
        File(context.filesDir, "logs").apply { mkdirs() }.let { File(it, "zflip.log") }

    fun init(context: Context) {
        if (file != null) return
        val f = logFile(context)
        file = f
        try {
            if (f.exists() && f.length() > MAX_BYTES) {
                val bytes = f.readBytes()
                f.writeBytes(bytes.copyOfRange(bytes.size - KEEP_BYTES, bytes.size))
            }
        } catch (_: Throwable) {
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, th ->
            try {
                e("Crash", "excepción no controlada en ${thread.name}: ${Log.getStackTraceString(th)}")
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, th)
        }
    }

    fun session(context: Context, title: String) {
        init(context)
        write('I', "ZFlip", "==== $title ====  Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}), ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
    }

    fun i(tag: String, msg: String) { Log.i(tag, msg); write('I', tag, msg) }
    fun w(tag: String, msg: String) { Log.w(tag, msg); write('W', tag, msg) }
    fun e(tag: String, msg: String) { Log.e(tag, msg); write('E', tag, msg) }

    private fun write(level: Char, tag: String, msg: String) {
        val f = file ?: return
        synchronized(lock) {
            try {
                f.appendText("${fmt.format(Date())} $level/$tag: $msg\n")
            } catch (_: Throwable) {
            }
        }
    }

    fun read(context: Context): String = try {
        val f = logFile(context)
        if (f.exists()) f.readText() else ""
    } catch (t: Throwable) {
        "No se pudo leer el registro: ${t.message}"
    }

    fun clear(context: Context) {
        try { logFile(context).writeText("") } catch (_: Throwable) {}
    }

    /**
     * Si la sesión anterior del juego no terminó limpiamente, copia al registro las últimas
     * advertencias/errores de logcat de la app (cierres nativos, errores JNI, etc.).
     */
    fun captureCrashContext(context: Context) {
        val sp = context.getSharedPreferences("zflip_state", Context.MODE_PRIVATE)
        if (!sp.getBoolean("running", false)) return
        sp.edit().putBoolean("running", false).apply()
        write('W', "ZFlip", "la sesión anterior NO terminó limpiamente; contexto de logcat (avisos/errores):")
        try {
            val p = ProcessBuilder("logcat", "-d", "-v", "time", "-b", "main,system,crash", "-t", "400", "*:W")
                .redirectErrorStream(true).start()
            val lines = p.inputStream.bufferedReader().readLines()
            p.waitFor()
            lines.takeLast(80).forEach { write('W', "logcat", it.take(300)) }
        } catch (t: Throwable) {
            write('E', "ZFlip", "no se pudo leer logcat: ${t.message}")
        }
    }

    /** Últimas líneas de logcat de esta app (no requiere permisos). */
    fun logcat(): String = try {
        val p = ProcessBuilder("logcat", "-d", "-v", "time", "-t", "1500").redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        text
    } catch (t: Throwable) {
        "No se pudo leer logcat: ${t.message}"
    }
}
