package com.zflip.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Visor de registros: registro de ZFlip (cargador, botón, mods) y logcat de la app. */
class LogsActivity : AppCompatActivity() {
    private lateinit var ui: Ui
    private lateinit var body: TextView
    private lateinit var scroll: ScrollView
    private var showLogcat = false
    private var current = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        ui = Ui(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            ui.pad(this, 12)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun add(label: String, color: Int = Ui.SECONDARY, action: () -> Unit) {
            bar.addView(ui.button(label, color, action), LinearLayout.LayoutParams(0, ui.dp(40), 1f).apply {
                rightMargin = ui.dp(6)
            })
        }
        add("← Volver") { finish() }
        add("ZFlip", Ui.ACCENT) { showLogcat = false; refresh() }
        add("Logcat") { showLogcat = true; refresh() }
        add("Actualizar") { refresh() }
        add("Copiar") { copy() }
        add("Compartir") { share() }
        add("Borrar", Ui.DANGER) { ZLog.clear(this); refresh() }
        root.addView(bar, LinearLayout.LayoutParams(-1, ui.dp(40)))
        root.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(8)))

        body = TextView(this).apply {
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(android.graphics.Color.rgb(200, 205, 225))
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.PANEL)
            addView(body)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        current = if (showLogcat) ZLog.logcat() else ZLog.read(this)
        if (current.isBlank()) current = "(vacío — abre el juego y vuelve aquí)"
        // mostrar solo el final para no bloquear la UI con textos enormes
        val shown = if (current.length > 120_000) "…\n" + current.takeLast(120_000) else current
        body.text = shown
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun payload(): String {
        val text = if (current.length > 90_000) current.takeLast(90_000) else current
        return "ZFlip ${if (showLogcat) "logcat" else "registro"}\n$text"
    }

    private fun copy() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ZFlip log", payload()))
        Toast.makeText(this, "Registro copiado", Toast.LENGTH_SHORT).show()
    }

    private fun share() {
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, payload())
                },
                "Compartir registro"
            )
        )
    }
}
