package com.zflip.launcher.utils

/**
 * Entradas "extendidas" que solo existen cuando un loader nativo las registra.
 * ZFlip no las usa: el código del juego usa siempre las rutas normales de cocos2d-x.
 * Se mantienen para que Cocos2dxGLSurfaceView compile; nunca se invocan.
 */
@Suppress("UNUSED_PARAMETER", "unused")
object NativeInput {
    fun nativeKeyUp(keyCode: Int, modifiers: Int) {}
    fun nativeKeyDown(keyCode: Int, modifiers: Int, isRepeating: Boolean) {}
    fun nativeActionScroll(scrollX: Float, scrollY: Float) {}
    fun resizeSurface(width: Int, height: Int) {}
    fun setNextInputTimestamp(timestamp: Long) {}

    const val TOUCH_TYPE_BEGIN = 0
    const val TOUCH_TYPE_MOVE = 1
    const val TOUCH_TYPE_END = 2
    const val TOUCH_TYPE_CANCEL = 3

    fun internalKeyEvent(timestamp: Long, deviceId: Int, eventSource: Int, keyCode: Int, modifiers: Int, isDown: Boolean, repeatCount: Int) {}
    fun internalTouchEvent(timestamp: Long, deviceId: Int, eventSource: Int, eventType: Int, ids: IntArray, xs: FloatArray, ys: FloatArray) {}
    fun internalScrollEvent(timestamp: Long, deviceId: Int, eventSource: Int, scrollX: Float, scrollY: Float, mouseX: Float, mouseY: Float) {}
    fun internalJoystickEvent(timestamp: Long, deviceId: Int, eventSource: Int, leftX: FloatArray, leftY: FloatArray, rightX: FloatArray, rightY: FloatArray, hatX: FloatArray, hatY: FloatArray, leftTrigger: FloatArray, rightTrigger: FloatArray) {}

    fun inputDeviceAdded(deviceId: Int) {}
    fun inputDeviceChanged(deviceId: Int) {}
    fun inputDeviceRemoved(deviceId: Int) {}
}
