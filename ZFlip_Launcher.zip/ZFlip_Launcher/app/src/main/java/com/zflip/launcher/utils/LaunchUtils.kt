package com.zflip.launcher.utils

import android.content.Context
import android.os.Build
import java.io.File
import java.io.Serializable

object LaunchUtils {
    // CPU_ABI devuelve la arquitectura del proceso actual
    @Suppress("DEPRECATION")
    val applicationArchitecture: String = Build.CPU_ABI

    val is64bit = applicationArchitecture == "arm64-v8a"

    /** Carpeta base visible para el usuario (Android/media/com.zflip.launcher). */
    fun getBaseDirectory(context: Context): File {
        @Suppress("DEPRECATION")
        val dir = context.externalMediaDirs.firstOrNull()
            ?: context.getExternalFilesDir(null)
            ?: context.filesDir

        dir.mkdirs()
        // evita que los recursos aparezcan en la galería
        File(dir, ".nomedia").createNewFile()
        return dir
    }

    fun getSaveDirectory(context: Context): File = File(getBaseDirectory(context), "save")

    /** Aquí van los archivos .zflip. */
    fun getModsDirectory(context: Context): File =
        File(getBaseDirectory(context), "mods").apply { mkdirs() }

    /** Carpeta privada de datos de cada mod. */
    fun getModDataDirectory(context: Context, modId: String): File =
        File(getBaseDirectory(context), "moddata/$modId").apply { mkdirs() }

    enum class LauncherError : Serializable {
        LINKER_NEEDS_64BIT,
        LINKER_NEEDS_32BIT,
        LINKER_FAILED_STL,
        LINKER_FAILED,
        GENERIC
    }

    const val KEY_RETURN_ERROR = "return_error"
    const val KEY_RETURN_MESSAGE = "return_message"
    const val KEY_RETURN_EXTENDED_MESSAGE = "return_extended_message"
}
