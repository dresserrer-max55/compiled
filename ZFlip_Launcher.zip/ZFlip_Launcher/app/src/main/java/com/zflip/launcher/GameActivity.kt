package com.zflip.launcher

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import com.customRobTop.BaseRobTopActivity
import com.customRobTop.JniToCpp
import com.zflip.launcher.utils.Constants
import com.zflip.launcher.utils.ConstrainedFrameLayout
import com.zflip.launcher.utils.DownloadUtils
import com.zflip.launcher.utils.GamePackageUtils
import com.zflip.launcher.utils.LaunchUtils
import org.cocos2dx.lib.Cocos2dxGLSurfaceView
import org.cocos2dx.lib.Cocos2dxHelper
import org.cocos2dx.lib.Cocos2dxRenderer
import org.fmod.FMOD
import java.io.File
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay

/**
 * Actividad que ejecuta Geometry Dash dentro del launcher: carga las librerías nativas del
 * juego instalado, después el motor de mods ZFlip, y muestra un botón «Mods» en el menú principal.
 */
class GameActivity : AppCompatActivity(), Cocos2dxHelper.Cocos2dxHelperListener, ZflipBridge.MenuListener {
    private var mGLSurfaceView: Cocos2dxGLSurfaceView? = null
    private var mIsRunning = false
    private var mIsOnPause = false
    private var mHasWindowFocus = false

    private var modsButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        ZLog.session(this, "Inicio del juego")
        ZLog.captureCrashContext(this)
        getSharedPreferences("zflip_state", MODE_PRIVATE).edit().putBoolean("running", true).apply()
        setupUIState()
        FMOD.init(this)

        super.onCreate(savedInstanceState)

        // vuelve al launcher si Geometry Dash no está instalado
        if (!GamePackageUtils.isGameInstalled(packageManager)) {
            returnToMain()
            return
        }

        try {
            tryLoadGame()
        } catch (e: UnsatisfiedLinkError) {
            ZLog.e("ZFlip", "Library linkage failure" + ": " + Log.getStackTraceString(e))

            val gdPackageInfo = packageManager.getPackageInfo(Constants.PACKAGE_NAME, 0)
            val abiMismatch = GamePackageUtils.detectAbiMismatch(this, gdPackageInfo, e)

            val is64bit = LaunchUtils.is64bit
            val errorMessage = when {
                abiMismatch && is64bit -> LaunchUtils.LauncherError.LINKER_NEEDS_32BIT
                abiMismatch -> LaunchUtils.LauncherError.LINKER_NEEDS_64BIT
                e.message?.contains("__gxx_personality_v0") == true ->
                    LaunchUtils.LauncherError.LINKER_FAILED_STL
                else -> LaunchUtils.LauncherError.LINKER_FAILED
            }

            returnToMain(errorMessage, e.message, e.stackTraceToString())
            return
        } catch (e: Exception) {
            ZLog.e("ZFlip", "Uncaught error during game load" + ": " + Log.getStackTraceString(e))

            returnToMain(
                LaunchUtils.LauncherError.GENERIC,
                e.message ?: "Unknown Exception",
                e.stackTraceToString()
            )
            return
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                mGLSurfaceView?.sendKeyBack()
            }
        })
        mGLSurfaceView?.manualBackEvents = true
    }

    private fun returnToMain(
        error: LaunchUtils.LauncherError? = null,
        returnMessage: String? = null,
        returnExtendedMessage: String? = null
    ) {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

            if (error != null && !returnMessage.isNullOrEmpty()) {
                putExtra(LaunchUtils.KEY_RETURN_ERROR, error)
                putExtra(LaunchUtils.KEY_RETURN_MESSAGE, returnMessage)
                putExtra(LaunchUtils.KEY_RETURN_EXTENDED_MESSAGE, returnExtendedMessage)
            }
        }

        startActivity(launchIntent)
    }

    private fun tryLoadGame() {
        val gdPackageInfo = packageManager.getPackageInfo(Constants.PACKAGE_NAME, 0)

        setupRedirection(gdPackageInfo)

        Cocos2dxHelper.init(this, this)

        tryLoadLibrary(gdPackageInfo, Constants.FMOD_LIB_NAME)
        tryLoadLibrary(gdPackageInfo, Constants.COCOS_LIB_NAME)

        val gameVersionCode = GamePackageUtils.getGameVersionCode(packageManager)
        if (gameVersionCode >= 39L) {
            LauncherFix.enableExceptionsRenaming()
        }

        LauncherFix.performPatches()

        val baseView = createView()
        if (gameVersionCode >= 42L) {
            mGLSurfaceView?.sendNewCocosEvents = true
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.BAKLAVA) {
            val frameLayoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            val frameLayout = FrameLayout(this)
            frameLayout.layoutParams = frameLayoutParams

            frameLayout.setOnApplyWindowInsetsListener { v, insets ->
                val displayInsets = insets.displayCutout
                if (displayInsets != null) {
                    v.updatePadding(
                        left = displayInsets.safeInsetLeft,
                        top = displayInsets.safeInsetTop,
                        right = displayInsets.safeInsetRight,
                        bottom = displayInsets.safeInsetBottom
                    )
                } else {
                    v.updatePadding(left = 0, top = 0, right = 0, bottom = 0)
                }

                Cocos2dxGLSurfaceView.onKeyboardInsets(insets)

                WindowInsets.CONSUMED
            }

            frameLayout.addView(baseView)
            setContentView(frameLayout)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                baseView.setOnApplyWindowInsetsListener { view, insets ->
                    Cocos2dxGLSurfaceView.onKeyboardInsets(insets)
                    return@setOnApplyWindowInsetsListener view.onApplyWindowInsets(insets)
                }
            }

            setContentView(baseView)
        }

        setupPostLibraryLoad(gdPackageInfo)

        // --- ZFlip: motor de hooks + mods. Un fallo aquí nunca debe impedir abrir el juego. ---
        ZflipBridge.appContext = applicationContext
        ZflipBridge.listener = this
        val unified = GamePackageUtils.getUnifiedVersionNameOrNull(packageManager) ?: "?"
        try {
            ZflipLoader.loadAll(this, unified)
        } catch (t: Throwable) {
            ZLog.e("ZFlip", "fallo inesperado cargando mods: ${Log.getStackTraceString(t)}")
        }
        addModsButton(baseView)
    }

    // ------------------------------------------------------------------ botón «Mods»

    private fun addModsButton(baseView: FrameLayout) {
        val density = resources.displayMetrics.density
        val button = Button(this).apply {
            text = "MODS"
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.argb(200, 102, 92, 255))
                cornerRadius = 12 * density
            }
            setPadding((14 * density).toInt(), 0, (14 * density).toInt(), 0)
            // botón de RESPALDO: solo se ve si el botón nativo dentro del menú del juego falla
            visibility = if (ZflipLoader.menuHooksOk && !ZflipLoader.alwaysFloating(this@GameActivity)) View.GONE else View.VISIBLE
            setOnClickListener { showModsDialog() }
        }
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, (38 * density).toInt(),
            Gravity.BOTTOM or Gravity.START
        )
        lp.leftMargin = (10 * density).toInt()
        lp.bottomMargin = (10 * density).toInt()
        baseView.addView(button, lp)
        modsButton = button
    }

    // visible = true cuando el botón nativo del menú no pudo crearse (botón de respaldo)
    override fun onMenuVisible(visible: Boolean) {
        ZLog.i("ZFlip", "botón de respaldo (overlay) ${if (visible) "visible" else "oculto"}")
        runOnUiThread {
            val always = ZflipLoader.alwaysFloating(this)
            modsButton?.visibility = if (visible || always || !ZflipLoader.menuHooksOk) View.VISIBLE else View.GONE
        }
    }

    override fun onShowMods() {
        ZLog.i("ZFlip", "botón MODS pulsado")
        runOnUiThread { showModsDialog() }
    }

    private fun showModsDialog() {
        val mods = ZflipLoader.listMods(this)
        val results = ZflipLoader.lastResults
        val good = Color.rgb(40, 150, 80)
        val bad = Color.rgb(200, 50, 60)
        val gray = Color.rgb(120, 120, 130)

        val sb = SpannableStringBuilder()
        fun line(text: String, color: Int) {
            val start = sb.length
            sb.append(text).append('\n')
            sb.setSpan(ForegroundColorSpan(color), start, sb.length - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        if (mods.isEmpty()) {
            line("No hay mods instalados.", gray)
            line("Añade archivos .zflip desde el launcher.", gray)
        }
        for (mod in mods) {
            val r = results[mod.id]
            val title = "${mod.name} ${mod.version}".trim()
            sb.append(title).append('\n')
            val (msg, color) = when {
                r?.state == ModState.LOADED -> "✔ cargado" to good
                r?.state == ModState.CRASHED -> "✖ ${r?.detail}" to bad
                r?.state == ModState.ERROR -> "✖ no se pudo ejecutar: ${r?.detail}" to bad
                !mod.compatible -> "✖ no se puede ejecutar: ${mod.reason}" to bad
                r?.state == ModState.DISABLED -> "• desactivado" to gray
                else -> "• se cargará al reiniciar el juego" to gray
            }
            line(msg, color)
            sb.append('\n')
        }

        AlertDialog.Builder(this)
            .setTitle("Mods (${mods.size})")
            .setMessage(sb)
            .setPositiveButton("OK", null)
            .show()
    }

    // ------------------------------------------------------------------ arranque del juego

    private fun setupRedirection(packageInfo: PackageInfo) {
        try {
            GamePackageUtils.addAssetsFromPackage(assets, packageInfo)
        } catch (e: NoSuchMethodException) {
            ZLog.e("ZFlip", "Failed to add asset redirection" + ": " + Log.getStackTraceString(e))
        }

        try {
            // arregla comportamientos del nuevo directorio de datos (nombre del paquete, etc.)
            val saveDir = LaunchUtils.getSaveDirectory(this)
            saveDir.mkdirs()

            System.loadLibrary("c++_shared")

            LauncherFix.loadLibrary()
            LauncherFix.setOriginalDataPath(Constants.GJ_DATA_DIR)
            LauncherFix.setDataPath(saveDir.path)
        } catch (e: UnsatisfiedLinkError) {
            ZLog.e("ZFlip", "Failed to load LauncherFix" + ": " + Log.getStackTraceString(e))
        }
    }

    private fun setupPostLibraryLoad(packageInfo: PackageInfo) {
        JniToCpp.setupHSSAssets(
            packageInfo.applicationInfo!!.sourceDir,
            Environment.getExternalStorageDirectory().absolutePath
        )
        Cocos2dxHelper.nativeSetApkPath(packageInfo.applicationInfo!!.sourceDir)

        BaseRobTopActivity.setCurrentActivity(this)
    }

    @SuppressLint("UnsafeDynamicallyLoadedCode")
    private fun tryLoadLibrary(packageInfo: PackageInfo, libraryName: String) {
        val nativeDir = getNativeLibraryDirectory(packageInfo.applicationInfo!!)
        val libraryPath = if (nativeDir.endsWith('/')) "${nativeDir}lib$libraryName.so" else "$nativeDir/lib$libraryName.so"

        try {
            System.load(libraryPath)
        } catch (ule: UnsatisfiedLinkError) {
            // some devices (samsung a series, cough) have an overly restrictive application classloader
            // this is a workaround for that. hopefully
            if (ule.message?.contains("not accessible for the namespace") != true) {
                throw ule
            }

            println("Using copy for library $libraryName")
            loadLibraryCopy(libraryName, libraryPath)
        }
    }

    @SuppressLint("UnsafeDynamicallyLoadedCode")
    private fun loadLibraryCopy(libraryName: String, libraryPath: String) {
        if (libraryPath.contains("!/")) {
            // library in apk can't be loaded directly
            loadLibraryFromAssetsCopy(libraryName)
            return
        }

        val library = File(libraryPath)
        val libraryCopy = File(cacheDir, "lib$libraryName.so")

        libraryCopy.outputStream().use { libraryOutput ->
            library.inputStream().use { inputStream ->
                DownloadUtils.copyFile(inputStream, libraryOutput)
            }
        }

        System.load(libraryCopy.path)

        return
    }

    @SuppressLint("UnsafeDynamicallyLoadedCode")
    private fun loadLibraryFromAssetsCopy(libraryName: String) {
        // loads a library loaded in assets
        // this copies the library to a non-compressed directory

        val arch = LaunchUtils.applicationArchitecture
        val libraryFd = try {
            assets.openNonAssetFd("lib/$arch/lib$libraryName.so")
        } catch (_: Exception) {
            throw UnsatisfiedLinkError("Could not find library lib$libraryName.so for abi $arch")
        }

        // copy the library to a path we can access
        // there doesn't seem to be a way to load a library from a file descriptor
        val libraryCopy = File(cacheDir, "lib$libraryName.so")

        libraryCopy.outputStream().use { libraryOutput ->
            libraryFd.createInputStream().use { inputStream ->
                DownloadUtils.copyFile(inputStream, libraryOutput)
            }
        }

        System.load(libraryCopy.path)

        return
    }

    private fun getNativeLibraryDirectory(applicationInfo: ApplicationInfo): String {
        // native libraries have been extracted, so the path is same as usual
        if (applicationInfo.flags and ApplicationInfo.FLAG_EXTRACT_NATIVE_LIBS == ApplicationInfo.FLAG_EXTRACT_NATIVE_LIBS) {
            return applicationInfo.nativeLibraryDir
        }

        // might be split apks, select the best path for the library
        val sourceDirs = applicationInfo.splitSourceDirs
        val architecture = LaunchUtils.applicationArchitecture

        if (!sourceDirs.isNullOrEmpty()) {
            val configAbi = architecture.replace("-", "_")
            val abiDir = sourceDirs.find { it.contains(configAbi) }

            if (abiDir != null) {
                return "$abiDir!/lib/$architecture/"
            }
        }

        // this configuration should never happen!
        // non split apk, but libraries are stored in apk
        val sourceDir = applicationInfo.sourceDir
        return "$sourceDir!/lib/$architecture/"
    }

    private fun createView(): FrameLayout {
        val frameLayoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        val frameLayout = ConstrainedFrameLayout(this)
        frameLayout.layoutParams = frameLayoutParams

        val editTextLayoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val editText = AppCompatEditText(this)
        editText.layoutParams = editTextLayoutParams
        frameLayout.addView(editText)

        val glSurfaceView = Cocos2dxGLSurfaceView(this)

        this.mGLSurfaceView = glSurfaceView
        frameLayout.addView(this.mGLSurfaceView)

        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.setEGLConfigChooser(EGLConfigChooser())

        glSurfaceView.initView()

        val renderer = Cocos2dxRenderer(glSurfaceView)
        glSurfaceView.setCocos2dxRenderer(renderer)

        renderer.setFrameRate = true

        editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        glSurfaceView.cocos2dxEditText = editText

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            glSurfaceView.defaultFocusHighlightEnabled = false
        }

        return frameLayout
    }

    private fun setupUIState() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val chosenDisplay = display.supportedModes?.maxByOrNull { it.refreshRate }
            if (chosenDisplay != null) {
                window.attributes.preferredRefreshRate = chosenDisplay.refreshRate
            }
        }

        hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)

        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }


    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        mHasWindowFocus = hasWindowFocus
        if (hasWindowFocus && !mIsOnPause) {
            resumeGame()
        }

        hideSystemUi()
    }

    override fun onDestroy() {
        ZLog.i("ZFlip", "GameActivity.onDestroy (isFinishing=$isFinishing)")
        if (isFinishing) getSharedPreferences("zflip_state", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        super.onDestroy()
        if (ZflipBridge.listener === this) ZflipBridge.listener = null
        FMOD.close()
    }

    private fun resumeGame() {
        mIsRunning = true
        Cocos2dxHelper.onResume()
        mGLSurfaceView?.onResume()
    }

    private fun pauseGame() {
        mIsRunning = false
        Cocos2dxHelper.onPause()
        mGLSurfaceView?.onPause()
    }

    override fun onResume() {
        super.onResume()
        mIsOnPause = false
        BaseRobTopActivity.isPaused = false
        if (mHasWindowFocus && !this.mIsRunning) {
            resumeGame()
        }
    }

    override fun onRestart() {
        super.onRestart()
        mIsOnPause = false
        BaseRobTopActivity.isPaused = false
        if (!this.mIsRunning) {
            resumeGame()
        }
    }

    override fun onPause() {
        super.onPause()
        mIsOnPause = true
        BaseRobTopActivity.isPaused = true
        if (mIsRunning) {
            pauseGame()
        }
    }

    override fun runOnGLThread(runnable: Runnable) {
        mGLSurfaceView?.queueEvent(runnable)
    }

    override fun showDialog(title: String, message: String) {
        runOnUiThread {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.message_box_accept) { _, _ -> }
                .show()
        }
    }

    override fun showEditTextDialog(
        title: String,
        message: String,
        inputMode: Int,
        inputFlag: Int,
        returnType: Int,
        maxLength: Int
    ) {
        TODO("Not yet implemented")
    }

    class EGLConfigChooser : GLSurfaceView.EGLConfigChooser {
        // this comes from EGL14, but is unavailable on EGL10
        // also EGL14 is incompatible with EGL10. so whatever
        private var EGL_OPENGL_ES2_BIT: Int = 0x04

        private data class ConfigValues(
            val redSize: Int,
            val greenSize: Int,
            val blueSize: Int,
            val alphaSize: Int,
            val depthSize: Int,
            val stencilSize: Int,
        )

        private fun getAttribValue(egl: EGL10, display: EGLDisplay, config: EGLConfig, attrib: Int): Int {
            val value = IntArray(1)
            egl.eglGetConfigAttrib(display, config, attrib, value)

            return value[0]
        }

        private fun testConfig(egl: EGL10, display: EGLDisplay, attrib: ConfigValues): EGLConfig? {
            val attribList = intArrayOf(
                EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                EGL10.EGL_RED_SIZE, attrib.redSize,
                EGL10.EGL_GREEN_SIZE, attrib.greenSize,
                EGL10.EGL_BLUE_SIZE, attrib.blueSize,
                EGL10.EGL_ALPHA_SIZE, attrib.alphaSize,
                EGL10.EGL_DEPTH_SIZE, attrib.depthSize,
                EGL10.EGL_STENCIL_SIZE, attrib.stencilSize,
                EGL10.EGL_NONE
            )

            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)

            val res = egl.eglChooseConfig(display, attribList, configs, configs.size, numConfigs)
            if (res && numConfigs[0] > 0 && configs[0] != null) {
                return configs[0]
            }

            return null
        }

        private fun printConfig(egl: EGL10, display: EGLDisplay, config: EGLConfig) {
            val id = getAttribValue(egl, display, config, EGL10.EGL_CONFIG_ID)
            val red = getAttribValue(egl, display, config, EGL10.EGL_RED_SIZE)
            val green = getAttribValue(egl, display, config, EGL10.EGL_GREEN_SIZE)
            val blue = getAttribValue(egl, display, config, EGL10.EGL_BLUE_SIZE)
            val alpha = getAttribValue(egl, display, config, EGL10.EGL_ALPHA_SIZE)
            val depth = getAttribValue(egl, display, config, EGL10.EGL_DEPTH_SIZE)
            val stencil = getAttribValue(egl, display, config, EGL10.EGL_STENCIL_SIZE)
            println("EGLConfig $id: (red = $red, green = $green, blue = $blue, alpha = $alpha, depth = $depth, stencil = $stencil)")
        }

        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
            val configs = listOf(
                ConfigValues(8, 8, 8, 8, 16, 8),
                ConfigValues(8, 8, 8, 0, 16, 8),
                ConfigValues(5, 6, 5, 0, 16, 8),
                ConfigValues(0, 0, 0, 0, 0, 0),
            )

            return configs.firstNotNullOf {
                val config = testConfig(egl, display, it)
                if (config != null) {
                    printConfig(egl, display, config)
                }

                config
            }
        }
    }
}
