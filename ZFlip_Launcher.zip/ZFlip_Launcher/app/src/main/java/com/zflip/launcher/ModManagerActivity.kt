package com.zflip.launcher

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.zflip.launcher.utils.GamePackageUtils
import com.zflip.launcher.utils.LaunchUtils
import java.io.File

/** Gestor de mods .zflip: añadir, activar/desactivar y eliminar. */
class ModManagerActivity : AppCompatActivity() {
    private lateinit var ui: Ui
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    private val pickMod = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addMod(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        ui = Ui(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            ui.pad(this, 16)
        }

        val version = GamePackageUtils.getUnifiedVersionNameOrNull(packageManager)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(ui.text("Mods", 22, bold = true))
        heading.addView(
            ui.text(
                if (version != null) "Geometry Dash detectado: $version" else "Geometry Dash no está instalado",
                12, Ui.MUTED
            )
        )
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(ui.button("＋ Añadir .zflip") { pickMod.launch(arrayOf("*/*")) }, LinearLayout.LayoutParams(-2, ui.dp(42)))
        top.addView(View(this), LinearLayout.LayoutParams(ui.dp(8), 1))
        top.addView(ui.button("Volver", Ui.SECONDARY) { finish() }, LinearLayout.LayoutParams(-2, ui.dp(42)))
        root.addView(top, LinearLayout.LayoutParams(-1, ui.dp(52)))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            background = ui.rounded(Ui.PANEL, 14)
            ui.pad(this, 10)
            addView(list)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        status = ui.text(
            "También puedes copiar archivos .zflip a: ${LaunchUtils.getModsDirectory(this).path}",
            11, Ui.MUTED
        )
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val mods = ZflipLoader.listMods(this)
        if (mods.isEmpty()) {
            list.addView(ui.text("No hay mods instalados.", 13, Ui.MUTED))
            return
        }
        for (m in mods) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                ui.pad(this, 8)
                background = ui.rounded(Ui.ROW, 10)
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(ui.text("${m.name}  ${m.version}", 14, bold = true))
            if (m.author.isNotEmpty() || m.description.isNotEmpty()) {
                labels.addView(
                    ui.text(listOf(m.author, m.description).filter { it.isNotEmpty() }.joinToString(" · "), 11, Ui.MUTED)
                )
            }
            labels.addView(
                ui.text(
                    if (m.compatible) "✔ ${m.reason}" else "✖ No se puede ejecutar: ${m.reason}",
                    11, if (m.compatible) Ui.GOOD else Ui.BAD
                )
            )
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))

            if (m.compatible) {
                val toggle = Switch(this).apply {
                    isChecked = ZflipLoader.isEnabled(this@ModManagerActivity, m.id)
                    setOnCheckedChangeListener { _, checked ->
                        ZflipLoader.setEnabled(this@ModManagerActivity, m.id, checked)
                        setStatus("${m.name}: ${if (checked) "activado" else "desactivado"}. Cambia al reiniciar el juego.")
                    }
                }
                row.addView(toggle)
                row.addView(View(this), LinearLayout.LayoutParams(ui.dp(10), 1))
            }
            row.addView(ui.button("Eliminar", Ui.DANGER) {
                m.file.delete()
                refresh()
                setStatus("Eliminado: ${m.name}")
            }, LinearLayout.LayoutParams(-2, ui.dp(36)))

            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = ui.dp(6)
            list.addView(row, lp)
        }
    }

    private fun addMod(uri: Uri) {
        val name = displayName(uri) ?: "mod.zflip"
        if (!name.endsWith(ZflipMod.EXTENSION, true)) {
            setStatus("«$name» no es un archivo .zflip.")
            return
        }
        try {
            val dest = File(LaunchUtils.getModsDirectory(this), name.replace('/', '_'))
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw Exception("no se pudo abrir el archivo")
                dest.outputStream().use { input.copyTo(it) }
            }
            refresh()
            val info = ZflipMod.parse(
                dest, GamePackageUtils.getUnifiedVersionNameOrNull(packageManager), LaunchUtils.applicationArchitecture
            )
            setStatus(
                if (info.compatible) "Instalado: ${info.name}. Se cargará la próxima vez que abras el juego."
                else "Instalado: ${info.name}, pero no se puede ejecutar (${info.reason}). El juego no se cerrará."
            )
        } catch (e: Exception) {
            setStatus("No se pudo instalar el mod: ${e.message ?: "error"}")
        }
    }

    private fun displayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun setStatus(message: String) {
        status.text = message
    }
}
