# ZFlip Launcher

Launcher de mods para Geometry Dash (Android) con su propio formato de mods: **.zflip**.
No usa ni depende de Geode.

* El launcher carga las librerías del Geometry Dash instalado y después el motor ZFlip (`libzflip.so`).
* Los mods son librerías nativas empaquetadas en `.zflip` (ver `sdk/`).
* Cada mod declara las versiones de GD que soporta; si no coincide, no se carga y se avisa sin cerrar el juego.
* En el menú principal del juego aparece un botón «MODS» con la lista y el estado de cada mod.

El código que arranca el juego en Android (clases `org.cocos2dx.*`, `org.fmod.*`, `com.customRobTop.*`
y el parche `launcherfix`) proviene del launcher oficial de Geode, licencia Boost
(https://github.com/geode-sdk/android-launcher); ver LICENSE.txt. Los hooks usan ShadowHook (MIT).
