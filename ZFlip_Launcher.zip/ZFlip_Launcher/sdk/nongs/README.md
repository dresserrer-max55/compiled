# NONGs (mod .zflip)

Cambia la música de un nivel por un audio tuyo.

* **Disco morado «O NONG»**: aparece en el menú de pausa (abajo al centro) y en la página del nivel (abajo a la izquierda).
* Al pulsarlo se abre la ventana: «Original» + tus NONGs. Tocar un nombre lo activa (verde), «X» lo borra (pide confirmación),
  «+ Agregar» abre el selector de archivos de Android (necesita el launcher con el parche de `BaseRobTopActivity.kt`).
* El cambio se aplica al volver a entrar al nivel.

Archivos: `Android/media/com.zflip.launcher/moddata/nongs/nongs/<clave>/` (`c<ID>` = canción personalizada,
`o<N>` = pista oficial). Si el botón «+» no funciona puedes copiar ahí los audios a mano.
Posición de los discos: `.../moddata/nongs/config.txt` (reinicia el juego tras editarlo).

Funciones del juego que engancha: `LevelTools::getAudioFileName`, `MusicDownloadManager::pathForSong`,
`MusicDownloadManager::isSongDownloaded` (imprescindibles: las dos primeras) y, opcionales,
`PlayLayer::init`, `LevelInfoLayer::init`, `MusicDownloadManager::getSongInfoObject`, `LevelTools::getAudioTitle`,
`JniToCpp.filesPicked`. En «Registros» aparece cuál se pudo enganchar.
