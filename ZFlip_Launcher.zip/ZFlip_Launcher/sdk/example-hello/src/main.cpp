// Mod de ejemplo: «Mini Mod Menu» que aparece sobre la pantalla de carga de Geometry Dash.
//
//  - Aviso en menú: muestra un aviso (toast) cuando se abre el menú principal.
//  - Velocidad: velocidad global del juego (0.5x / 1x / 1.5x / 2x).
//  - Ocultar: pliega el panel a una pestaña «ZFlip».
//
// Los ajustes se guardan en <data_dir>/settings.txt.
#include <cstdio>
#include <cstring>
#include <string>

#include "zflip.h"

static const ZflipApi* g_api = nullptr;

// ------------------------------------------------------------------ ajustes
static bool g_toastOnMenu = true;
static int g_speedIdx = 1;
static const float kSpeeds[] = {0.5f, 1.0f, 1.5f, 2.0f};
static const char* kSpeedText[] = {"Velocidad: 0.5x", "Velocidad: 1.0x", "Velocidad: 1.5x", "Velocidad: 2.0x"};

static std::string settingsPath() { return std::string(g_api->data_dir) + "/settings.txt"; }

static void loadSettings() {
    FILE* f = fopen(settingsPath().c_str(), "r");
    if (!f) return;
    int t = 1, s = 1;
    if (fscanf(f, "toast=%d\nspeed=%d", &t, &s) >= 1) {
        g_toastOnMenu = t != 0;
        if (s >= 0 && s < 4) g_speedIdx = s;
    }
    fclose(f);
}

static void saveSettings() {
    FILE* f = fopen(settingsPath().c_str(), "w");
    if (!f) return;
    fprintf(f, "toast=%d\nspeed=%d\n", g_toastOnMenu ? 1 : 0, g_speedIdx);
    fclose(f);
}

// ------------------------------------------------------------------ interfaz
static void* g_panelRect = nullptr;
static void* g_panelTitle = nullptr;
static void* g_panelMenu = nullptr;
static void* g_tabMenu = nullptr;
static void* g_btnToast = nullptr;
static void* g_btnSpeed = nullptr;

static void refreshToastButton() {
    g_api->ui_set_text(g_btnToast, g_toastOnMenu ? "Aviso en menu: ON" : "Aviso en menu: OFF");
    if (g_toastOnMenu) g_api->ui_set_color(g_btnToast, 90, 220, 120);
    else g_api->ui_set_color(g_btnToast, 235, 90, 100);
}

static void applySpeed() {
    if (g_api->set_time_scale && g_api->set_time_scale(kSpeeds[g_speedIdx]) == 0) {
        g_api->ui_set_text(g_btnSpeed, kSpeedText[g_speedIdx]);
        g_api->ui_set_color(g_btnSpeed, g_speedIdx == 1 ? 255 : 255, g_speedIdx == 1 ? 255 : 210, g_speedIdx == 1 ? 255 : 90);
    } else {
        g_api->ui_set_text(g_btnSpeed, "Velocidad: no disponible");
        g_api->ui_set_color(g_btnSpeed, 150, 150, 160);
    }
}

static void onToggleToast(void*) {
    g_toastOnMenu = !g_toastOnMenu;
    refreshToastButton();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, g_toastOnMenu ? "aviso en menu: ON" : "aviso en menu: OFF");
}

static void onSpeed(void*) {
    g_speedIdx = (g_speedIdx + 1) % 4;
    applySpeed();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, kSpeedText[g_speedIdx]);
}

static void setPanelVisible(bool v) {
    g_api->ui_set_visible(g_panelRect, v);
    g_api->ui_set_visible(g_panelTitle, v);
    g_api->ui_set_visible(g_panelMenu, v);
    g_api->ui_set_visible(g_tabMenu, !v);
}

static void onHide(void*) { setPanelVisible(false); }
static void onShow(void*) { setPanelVisible(true); }

static bool haveUi() {
    return g_api->struct_size >= sizeof(ZflipApi) && g_api->ui_win_size && g_api->ui_rect &&
           g_api->ui_label && g_api->ui_menu && g_api->ui_button && g_api->ui_set_text;
}

static void buildMenu(void* layer) {
    float w = 0, h = 0;
    g_api->ui_win_size(&w, &h);
    if (w <= 0 || h <= 0) {
        g_api->log(ZFLIP_LOG_WARN, "mini menu: tamano de ventana invalido");
        return;
    }
    const float pw = 190.f, ph = 112.f, x0 = 8.f, y0 = h - 8.f - ph;
    const float cx = x0 + pw / 2;
    const int z = 1000;

    g_panelRect = g_api->ui_rect(layer, x0, y0, pw, ph, 0, 0, 0, 170, z);
    g_panelTitle = g_api->ui_label(layer, "ZFlip Mini Menu", 0.42f, cx, y0 + ph - 14.f, z + 1);
    if (g_api->ui_set_color && g_panelTitle) g_api->ui_set_color(g_panelTitle, 140, 130, 255);

    g_panelMenu = g_api->ui_menu(layer, z + 2);
    g_btnToast = g_api->ui_button(g_panelMenu, "Aviso en menu: ON", 0.36f, cx, y0 + ph - 40.f, onToggleToast, nullptr);
    g_btnSpeed = g_api->ui_button(g_panelMenu, "Velocidad: 1.0x", 0.36f, cx, y0 + ph - 66.f, onSpeed, nullptr);
    g_api->ui_button(g_panelMenu, "Ocultar", 0.36f, cx, y0 + ph - 92.f, onHide, nullptr);

    g_tabMenu = g_api->ui_menu(layer, z + 2);
    g_api->ui_button(g_tabMenu, "[ZFlip]", 0.4f, 38.f, h - 14.f, onShow, nullptr);

    if (g_btnToast) refreshToastButton();
    if (g_btnSpeed) applySpeed();
    setPanelVisible(true);
    g_api->log(ZFLIP_LOG_INFO, "mini menu creado en la pantalla de carga");
}

// ------------------------------------------------------------------ hooks
static bool (*orig_LoadingLayer_init)(void*, bool) = nullptr;
static bool hook_LoadingLayer_init(void* self, bool refresh) {
    bool r = orig_LoadingLayer_init(self, refresh);
    if (r && self) {
        if (haveUi()) buildMenu(self);
        else g_api->log(ZFLIP_LOG_WARN, "mini menu: el juego no ofrece la API de interfaz");
    }
    return r;
}

static bool (*orig_MenuLayer_init)(void*) = nullptr;
static bool hook_MenuLayer_init(void* self) {
    bool r = orig_MenuLayer_init(self);
    if (g_toastOnMenu) g_api->toast("ZFlip Mini Menu activo");
    return r;
}

extern "C" __attribute__((visibility("default"))) int zflip_main(const ZflipApi* api) {
    g_api = api;
    api->log(ZFLIP_LOG_INFO, "mini menu: cargado");
    loadSettings();

    int rc = api->hook_symbol("_ZN12LoadingLayer4initEb",
                              reinterpret_cast<void*>(hook_LoadingLayer_init),
                              reinterpret_cast<void**>(&orig_LoadingLayer_init));
    if (rc != 0) api->log(ZFLIP_LOG_ERROR, "mini menu: no se pudo enganchar LoadingLayer::init");

    int rc2 = api->hook_symbol("_ZN9MenuLayer4initEv",
                               reinterpret_cast<void*>(hook_MenuLayer_init),
                               reinterpret_cast<void**>(&orig_MenuLayer_init));
    if (rc2 != 0) api->log(ZFLIP_LOG_ERROR, "mini menu: no se pudo enganchar MenuLayer::init");
    return (rc == 0 || rc2 == 0) ? 0 : 1;
}
