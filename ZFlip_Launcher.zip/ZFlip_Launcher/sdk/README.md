# ZFlip SDK

Un mod `.zflip` es un **zip** con esta estructura:

```
mimod.zflip
├── manifest.json
└── lib/
    ├── arm64-v8a/mod.so
    └── armeabi-v7a/mod.so
```

## manifest.json

```json
{
  "id": "hello",              // identificador único
  "name": "Hello",
  "version": "1.0.0",
  "author": "tú",
  "description": "...",
  "gd": ["2.209", "2.2091"], // versiones de GD soportadas, o "*" para cualquiera
  "lib": "mod.so"             // opcional; nombre de la librería dentro de lib/<abi>/
}
```

Si la versión de GD instalada no está en `gd`, el mod **no se carga**: el launcher y el botón «MODS»
del juego muestran «No se puede ejecutar: requiere GD X» y el juego sigue funcionando.

## Código

Tu librería exporta `zflip_main` (ver `include/zflip.h`) y usa `api->hook_symbol` con los nombres
exportados por `libcocos2dcpp.so` (por ejemplo `_ZN9MenuLayer4initEv`). Mira `example-hello/`.

Compilar para cada ABI con el NDK:

```
cmake -S example-hello -B build/arm64 \
  -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-23 -DANDROID_STL=c++_shared
cmake --build build/arm64
```

Después copia `libmod.so` a `lib/arm64-v8a/mod.so` (igual para armeabi-v7a), añade `manifest.json`
y comprime todo en un zip con extensión `.zflip`.

Si un mod tumba el juego al cargarse, el launcher lo desactiva solo en el siguiente arranque.

## API de interfaz (v2)

`ZflipApi` incluye ayudas para crear interfaz dentro del juego sin cabeceras de cocos2d-x
(`ui_rect`, `ui_label`, `ui_menu`, `ui_button`, `ui_set_text`, `ui_set_color`, `ui_set_visible`,
`ui_win_size`) y `set_time_scale`. `example-hello` es un mini mod menu sobre la pantalla de carga
(engancha `LoadingLayer::init`). Comprueba siempre que el puntero no sea NULL.

## Registros

La app tiene una pantalla «Registros (logs)» con el registro de ZFlip y el logcat. `api->log` escribe ahí.

## Eventos (API v3) — importante

ZFlip usa shadowhook en modo UNIQUE: cada función del juego solo se puede enganchar una vez.
`MenuLayer::init` y `LoadingLayer::init` los engancha ZFlip; los mods se suscriben con
`api->on_menu_layer(cb)` y `api->on_loading_layer(cb)` (cb(layer) se llama tras la función original).
Enganchar esas dos funciones directamente con `hook_symbol` fallará.

## Menú de pausa (API v4)

`api->on_pause_layer(cb)` te avisa cuando se crea el menú de pausa de un nivel (`PauseLayer::customSetup`).
Como esa capa captura los toques, crea tus menús con `ui_menu` y súbeles la prioridad con
`ui_menu_priority(menu, -600)`. `example-hello` añade ahí una pestaña «[ZFlip]» con Noclip, velocidad y aviso.
