#pragma once
#include "VisualPlayer.hpp"
#include "ProgressArrow.hpp"
#include "ProgressIcon.hpp"
#include "../../audio/sound/VoiceStream.hpp"

#include <cocos2d.h>

namespace globed {

struct GameCameraState;
struct PlayerStateFlags;

struct RemotePlayerUpdate {
    PlayerState state;
    GameCameraState camState;
    PlayerStateFlags flags;

    bool forceHide = false;
    bool forceVisibility = false;
    bool noCulling = false;
};

class GLOBED_DLL RemotePlayer : public std::enable_shared_from_this<RemotePlayer> {
public:
    RemotePlayer(int playerId, GJBaseGameLayer* gameLayer, cocos2d::CCNode* parentNode);
    ~RemotePlayer();
    GLOBED_NOCOPY(RemotePlayer);
    GLOBED_NOMOVE(RemotePlayer);

    void update(const RemotePlayerUpdate& update);
    void handleDeath(const PlayerDeath& death);
    void handleSpiderTp(const SpiderTeleportData& tp, bool p1);
    bool isDataInitialized() const;
    bool isDataOutdated() const;
    bool isTeamInitialized() const;
    void markDataOutdated();
    void initData(const PlayerDisplayData& data, bool outdated, uint16_t teamId = 0xffff);
    void updateTeam(uint16_t teamId);
    bool isTeammate(bool whatWhenNoTeams = true);

    void updateLevelMeta(const PlayerLevelMeta& meta);
    std::optional<PlayerLevelMeta> getLevelMeta() const;

    void setForceHide(bool hide);

    VisualPlayer* player1();
    VisualPlayer* player2();

    PlayerDisplayData& displayData();
    int id() const;
    bool isLocal() const;

    bool isPlayer1Culled();
    bool isPlayer2Culled();

    void stopVoiceStream();
    void playVoiceData(EncodedAudioFrame frame);
    VoiceStream* getVoiceStream();

private:
    friend class VisualPlayer;

    PlayerState m_state;
    PlayerDisplayData m_data;
    std::optional<PlayerIconData> m_pendingIcons;
    std::optional<PlayerLevelMeta> m_levelMeta;
    bool m_dataInitialized = false;
    bool m_dataOutdated = false;
    bool m_forceHide = false;
    bool m_player1Culled = false;
    bool m_player2Culled = false;
    bool m_localPlayer = false;
    bool m_wasDead = false;
    cocos2d::CCNode* m_parentNode = nullptr;
    Ref<VisualPlayer> m_player1 = nullptr;
    Ref<VisualPlayer> m_player2 = nullptr;
    Ref<ProgressArrow> m_progArrow = nullptr;
    Ref<ProgressIcon> m_progIcon = nullptr;
    std::optional<uint16_t> m_teamId;
    std::shared_ptr<VoiceStream> m_voiceStream;
    std::shared_ptr<std::mutex> m_voiceStreamMutex;

    void beginDataUpdate();
    void doUpdateIcons();
};

}