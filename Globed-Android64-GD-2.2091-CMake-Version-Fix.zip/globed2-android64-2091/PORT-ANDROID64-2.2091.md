# Experimental Android64 build target for Geometry Dash 2.2091

This source package prepares an Android64-only GitHub Actions build of Globed and changes the Android manifest target to GD 2.2091. It is **not a precompiled or tested .geode file**.

## Build
1. Fork this repository into your GitHub account.
2. Push this source to the fork (or upload these files to a repository).
3. Open **Actions → Experimental Globed Android64 for GD 2.2091 → Run workflow**.
4. Download the `globed-android64-gd-2.2091-experimental` artifact if the workflow succeeds.
5. Install only after confirming that your Geode loader itself is built for Geometry Dash 2.2091 ARM64.

## Compatibility warning
Changing the manifest target does not port function addresses or fix an incompatible Geode loader. The build uses the current `latest` Geode SDK, so it may fail or produce a package that does not load if the SDK/bindings/loader are not ready for GD 2.2091. Do not treat a successful compile as runtime verification.
