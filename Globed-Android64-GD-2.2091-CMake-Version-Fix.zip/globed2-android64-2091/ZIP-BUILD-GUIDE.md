# Build Globed from an uploaded ZIP

This workflow can extract the Globed source archive from the repository and then run the Android64 Geode build.

## One-time setup

GitHub only loads Actions workflows from `.github/workflows/` in the repository itself; it does not run a workflow that exists only inside an uploaded ZIP. Therefore, first create/push this project (including `.github/workflows/build.yml`) to your repository.

## Each build

1. Upload the original Globed source ZIP to the **root of the repository** and commit/push it. The filename can be any `.zip` name as long as it is the only ZIP in the repository (excluding Git internals).
2. The workflow starts on that push, extracts the archive, locates the project root by `CMakeLists.txt` + `mod.json.template`, and builds `Android64`.
3. Open **Actions**, select the run, and download `globed-android64-gd-2.2091-experimental` from **Artifacts** if the build succeeds.

If there are multiple ZIP files, add a repository Actions variable named `GLOBED_SOURCE_ZIP` with the desired relative path, for example `globed2-main.zip`. For a manual run, the same variable selects the ZIP. Do not upload APKs or unrelated ZIPs alongside the source unless you set that variable.

## Important

This workflow automates extraction and compilation; it does not itself guarantee that Geode bindings or Globed are compatible with Geometry Dash 2.2091. A successful build is not the same as a successful in-game test.
