#define GEODE_DEFINE_EVENT_EXPORTS

#include <globed/soft-link/API.hpp>
#include <globed/core/net/NetworkManager.hpp>
#include <globed/core/FriendListManager.hpp>
#include <globed/core/RoomManager.hpp>
#include <core/Core.hpp>
#include <core/hooks/GJBaseGameLayer.hpp>
#include <core/net/NetworkManagerImpl.hpp>
#include <core/preload/PreloadManager.hpp>
#include <asp/format.hpp>

#ifndef GLOBED_SOFTLINK_API_EVENT_EXPORTED
# error "Did not successfully export the getRootTable function, likely PCH interference"
#endif

using namespace geode::prelude;

namespace globed {

RootApiTable::RootApiTable() {}

NetSubtable::NetSubtable() : VTable(sizeof(NetSubtable)) {}
GameSubtable::GameSubtable() : VTable(sizeof(GameSubtable)) {}
PlayerSubtable::PlayerSubtable() : VTable(sizeof(PlayerSubtable)) {}
MiscSubtable::MiscSubtable() : VTable(sizeof(MiscSubtable)) {}
RoomSubtable::RoomSubtable() : VTable(sizeof(RoomSubtable)) {}
ModuleSubtable::ModuleSubtable() : VTable(sizeof(ModuleSubtable)) {}
UserSubtable::UserSubtable() : VTable(sizeof(UserSubtable)) {}
SettingSubtable::SettingSubtable() : VTable(sizeof(SettingSubtable)) {}

static NetSubtable* makeNetTable() {
    auto table = new NetSubtable;

    GLOBED_VTABLE_INIT(table, disconnect, () {
        NetworkManagerImpl::get().disconnectCentral();
    });

    GLOBED_VTABLE_INIT(table, isConnected, () {
        return NetworkManagerImpl::get().isConnected();
    });

    GLOBED_VTABLE_INIT(table, getConnectionState, () {
        return NetworkManager::get().getConnectionState();
    });

    GLOBED_VTABLE_INIT(table, getCentralPingMs, () -> uint32_t {
        return NetworkManagerImpl::get().getCentralPing().millis();
    });

    GLOBED_VTABLE_INIT(table, getGamePingMs, () -> uint32_t {
        return NetworkManagerImpl::get().getGamePing().millis();
    });

    GLOBED_VTABLE_INIT(table, getGameTickrate, () {
        return NetworkManagerImpl::get().getGameTickrate();
    });

    GLOBED_VTABLE_INIT(table, getAllRoles, () {
        return NetworkManagerImpl::get().getAllRoles();
    });

    GLOBED_VTABLE_INIT(table, getUserRoles, () {
        return NetworkManagerImpl::get().getUserRoles();
    });

    GLOBED_VTABLE_INIT(table, getUserRoleIds, () {
        return NetworkManagerImpl::get().getUserRoleIds();
    });

    GLOBED_VTABLE_INIT(table, getUserHighestRole, () {
        return NetworkManagerImpl::get().getUserHighestRole();
    });

    GLOBED_VTABLE_INIT(table, findRole, (uint8_t id) {
        return NetworkManagerImpl::get().findRole(id);
    });

    GLOBED_VTABLE_INIT(table, findRoleStr, (std::string_view id) {
        return NetworkManagerImpl::get().findRole(id);
    });

    GLOBED_VTABLE_INIT(table, isModerator, () {
        return NetworkManagerImpl::get().isModerator();
    });

    GLOBED_VTABLE_INIT(table, isAuthorizedModerator, () {
        return NetworkManagerImpl::get().isAuthorizedModerator();
    });

    GLOBED_VTABLE_INIT(table, invalidateIcons, () {
        NetworkManagerImpl::get().invalidateIcons(true);
    });

    GLOBED_VTABLE_INIT(table, invalidateFriendList, () {
        NetworkManagerImpl::get().invalidateFriendList();
    });

    GLOBED_VTABLE_INIT(table, getFeaturedLevel, () {
        return NetworkManagerImpl::get().getFeaturedLevel();
    });

    GLOBED_VTABLE_INIT(table, sendEvent, (std::string_view id, std::vector<uint8_t> data, const EventOptions& options) {
        NetworkManagerImpl::get().sendEvent(id, std::move(data), options);
    });

    GLOBED_VTABLE_INIT(table, registerEvent, (std::string_view id, EventServer server) {
        NetworkManagerImpl::get().registerEvent(id, server);
    });

    return table;
}

static GameSubtable* makeGameTable() {
    auto table = new GameSubtable;

    GLOBED_VTABLE_INIT(table, isActive, () {
        return (bool)GlobedGJBGL::getActive();
    });

    GLOBED_VTABLE_INIT(table, isSafeMode, () {
        auto gjbgl = GlobedGJBGL::getActive();
        return gjbgl && gjbgl->isSafeMode();
    });

    GLOBED_VTABLE_INIT(table, killLocalPlayer, (bool fake) {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->killLocalPlayer(fake);
    });

    GLOBED_VTABLE_INIT(table, cancelLocalRespawn, () {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->cancelLocalRespawn();
    });

    GLOBED_VTABLE_INIT(table, causeLocalRespawn, (bool full) {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->causeLocalRespawn(full);
    });

    GLOBED_VTABLE_INIT(table, enableSafeMode, () {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->enableSafeMode();
    });

    GLOBED_VTABLE_INIT(table, resetSafeMode, () {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->resetSafeMode();
    });

    GLOBED_VTABLE_INIT(table, enablePermanentSafeMode, () {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->setPermanentSafeMode();
    });

    GLOBED_VTABLE_INIT(table, toggleCullingEnabled, (bool culling) {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->toggleCullingEnabled(culling);
    });

    GLOBED_VTABLE_INIT(table, toggleExtendedData, (bool extended) {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->toggleExtendedData(extended);
    });

    GLOBED_VTABLE_INIT(table, playSelfEmote, (uint32_t id) {
        if (auto gjbgl = GlobedGJBGL::getActive()) return gjbgl->playSelfEmote(id);
        return false;
    });

    GLOBED_VTABLE_INIT(table, playSelfFavoriteEmote, (uint32_t which) {
        if (auto gjbgl = GlobedGJBGL::getActive()) return gjbgl->playSelfFavoriteEmote(which);
        return false;
    });

    GLOBED_VTABLE_INIT(table, getPlayer, (int playerId) -> RemotePlayer* {
        auto gjbgl = GlobedGJBGL::getActive();
        if (!gjbgl || !gjbgl->active()) return nullptr;
        return gjbgl->getPlayer(playerId).get();
    });

    GLOBED_VTABLE_INIT(table, updateLocalIcons, (std::optional<PlayerIconData> icons) {
        if (auto gjbgl = GlobedGJBGL::getActive()) gjbgl->updateLocalIcons(icons);
    });

    GLOBED_VTABLE_INIT(table, getPlayerIds, -> std::vector<int> {
        if (auto gjbgl = GlobedGJBGL::getActive()) {
            return asp::iter::keys(gjbgl->m_fields->m_players).collect();
        }
        return {};
    });

    GLOBED_VTABLE_INIT(table, getPlayers, () -> std::vector<std::shared_ptr<RemotePlayer>> {
        if (auto gjbgl = GlobedGJBGL::getActive()) {
            return asp::iter::values(gjbgl->m_fields->m_players).collect();
        }
        return {};
    });

    GLOBED_VTABLE_INIT(table, getPlayerCount, () -> size_t {
        if (auto gjbgl = GlobedGJBGL::getActive()) {
            return gjbgl->m_fields->m_players.size();
        }
        return 0;
    });

    GLOBED_VTABLE_INIT(table, warpToSession, (const WarpContext& ctx) {
        globed::warpToSession(ctx);
    });

    GLOBED_VTABLE_INIT(table, warpToSession2, (int levelId) {
        globed::warpToSession(WarpContext {
            .session = RoomManager::get().makeSessionId(levelId),
            .source = WarpSource::Manual
        });
    });

    return table;
}

static PlayerSubtable* makePlayerTable() {
    auto table = new PlayerSubtable;

    GLOBED_VTABLE_INIT(table, isGlobedPlayer, (PlayerObject* player) {
        return typeinfo_cast<VisualPlayer*>(player) != nullptr;
    });

    GLOBED_VTABLE_INIT(table, getFirst, (RemotePlayer* rp) -> VisualPlayer* {
        return rp ? rp->player1() : nullptr;
    });

    GLOBED_VTABLE_INIT(table, getSecond, (RemotePlayer* rp) -> VisualPlayer* {
        return rp ? rp->player2() : nullptr;
    });

    GLOBED_VTABLE_INIT(table, getRemote, (VisualPlayer* vp) -> RemotePlayer* {
        return vp ? vp->getRemotePlayer() : nullptr;
    });

    GLOBED_VTABLE_INIT(table, isTeammate, (RemotePlayer* rp) {
        return rp ? rp->isTeammate(true) : true;
    });

    GLOBED_VTABLE_INIT(table, getAccountId, (RemotePlayer* rp) {
        return rp ? rp->id() : 0;
    });

    GLOBED_VTABLE_INIT(table, getUsername, (RemotePlayer* rp) {
        return rp ? rp->displayData().username : std::string("");
    });

    GLOBED_VTABLE_INIT(table, getIcons, (RemotePlayer* rp) -> Result<PlayerIconData> {
        if (!rp) return Err("null RemotePlayer was passed");
        return Ok(rp->displayData().icons);
    });

    GLOBED_VTABLE_INIT(table, setForceHide, (RemotePlayer* rp, bool hide) {
        if (rp) rp->setForceHide(hide);
    });

    return table;
}

static MiscSubtable* makeMiscTable() {
    auto table = new MiscSubtable;

    GLOBED_VTABLE_INIT(table, fullPathForFilename, (std::string_view filename, bool ignoreSuffix) {
        return PreloadManager::get().fullPathForFilename(filename, ignoreSuffix);
    });

    return table;
}

static RoomSubtable* makeRoomTable() {
    auto table = new RoomSubtable;

    GLOBED_VTABLE_INIT(table, isInRoom, () {
        return RoomManager::get().isInRoom();
    });

    GLOBED_VTABLE_INIT(table, getId, () {
        auto& rm = RoomManager::get();
        return rm.getRoomId();
    });

    GLOBED_VTABLE_INIT(table, isOwner, () {
        return RoomManager::get().isOwner();
    });

    GLOBED_VTABLE_INIT(table, getOwner, () {
        return RoomManager::get().getRoomOwner();
    });

    GLOBED_VTABLE_INIT(table, pickServerId, () {
        return RoomManager::get().pickServerId();
    });

    GLOBED_VTABLE_INIT(table, getSettings, () {
        // keeping abi :)
        // TODO (2.209) make it return non pointer
        static thread_local RoomSettings settings;
        settings = RoomManager::get().getSettings();
        return &settings;
    });

    GLOBED_VTABLE_INIT(table, getPasscode, () {
        return RoomManager::get().getPasscode();
    });

    GLOBED_VTABLE_INIT(table, getPinnedLevel, () {
        return RoomManager::get().getPinnedLevel();
    });

    GLOBED_VTABLE_INIT(table, getCurrentWarpLevel, () {
        return RoomManager::get().getCurrentWarpLevel();
    });

    // teams

    GLOBED_VTABLE_INIT(table, getCurrentTeamId, () {
        return RoomManager::get().getCurrentTeamId();
    });

    GLOBED_VTABLE_INIT(table, getCurrentTeam, () {
        return RoomManager::get().getCurrentTeam();
    });

    GLOBED_VTABLE_INIT(table, getTeam, (uint16_t id) {
        return RoomManager::get().getTeam(id);
    });

    GLOBED_VTABLE_INIT(table, getTeamIdForPlayer, (int playerId) {
        return RoomManager::get().getTeamIdForPlayer(playerId);
    });

    GLOBED_VTABLE_INIT(table, getName, () {
        return RoomManager::get().getRoomName();
    });

    // session id

    GLOBED_VTABLE_INIT(table, makeSessionId, (int levelId) {
        return RoomManager::get().makeSessionId(levelId);
    });

    return table;
}

static ModuleSubtable* makeModuleTable() {
    auto table = new ModuleSubtable{};

    GLOBED_VTABLE_INIT(table, register_, (ModuleVTable* vtable) {
        auto res = ModuleImpl::create(vtable);
        if (!res) {
            log::warn("failed to create module: {}", res.unwrapErr());
            return false;
        }
        return Core::get().addModule(res.unwrap());
    });

    GLOBED_VTABLE_INIT(table, isRegistered, (std::string_view id) {
        return Core::get().findModule(id) != nullptr;
    });

    GLOBED_VTABLE_INIT(table, isEnabled, (std::string_view id) {
        auto module = Core::get().findModule(id);
        return module && module->isEnabled();
    });

    GLOBED_VTABLE_INIT(table, setEnabled, (std::string_view id, bool enabled) -> Result<> {
        auto module = Core::get().findModule(id);
        if (!module) {
            return Err("module not found");
        }
        return enabled ? module->enable() : module->disable();
    });

    GLOBED_VTABLE_INIT(table, setAutoEnableMode, (std::string_view id, AutoEnableMode mode) {
        auto module = Core::get().findModule(id);
        if (module) module->setAutoEnableMode(mode);
        else {
            log::warn("setAutoEnableMode for '{}' failed: not found!", id);
        }
    });

    GLOBED_VTABLE_INIT(table, claimHooks, (std::string_view id, std::span<geode::Hook* const> hooks) {
        auto module = Core::get().findModule(id);
        if (module) module->claimHooks(hooks);
        else {
            log::warn("claimHooks for '{}' failed: not found!", id);
        }
    });

    GLOBED_VTABLE_INIT(table, claimPatches, (std::string_view id, std::span<geode::Patch* const> patches) {
        auto module = Core::get().findModule(id);
        if (module) module->claimPatches(patches);
        else {
            log::warn("claimPatches for '{}' failed: not found!", id);
        }
    });

    return table;
}

static UserSubtable* makeUserTable() {
    auto table = new UserSubtable{};

    GLOBED_VTABLE_INIT(table, isFriend, (int accountId) {
        return FriendListManager::get().isFriend(accountId);
    });

    GLOBED_VTABLE_INIT(table, isBlocked, (int accountId) {
        return FriendListManager::get().isBlocked(accountId);
    });

    GLOBED_VTABLE_INIT(table, openModPanel, (int accountId) {
        globed::openModPanel(accountId);
    });

    return table;
}

static SettingSubtable* makeSettingsTable() {
    auto table = new SettingSubtable{};

    GLOBED_VTABLE_INIT(table, hasSetting, (std::string_view key) {
        return SettingsManager::get().hasSetting(key);
    });

    GLOBED_VTABLE_INIT(table, getBool, (std::string_view key) {
        return setting<bool>(key).valueOpt();
    });

    GLOBED_VTABLE_INIT(table, getInt, (std::string_view key) {
        return setting<int>(key).valueOpt();
    });

    GLOBED_VTABLE_INIT(table, getString, (std::string_view key) {
        return setting<std::string>(key).valueOpt();
    });

    GLOBED_VTABLE_INIT(table, getRaw, (std::string_view key) {
        return setting<matjson::Value>(key).valueOpt();
    });

    GLOBED_VTABLE_INIT(table, setBool, (std::string_view key, bool value) {
        return setting<bool>(key).trySet(value);
    });

    GLOBED_VTABLE_INIT(table, setInt, (std::string_view key, int value) {
        return setting<int>(key).trySet(value);
    });

    GLOBED_VTABLE_INIT(table, setString, (std::string_view key, std::string value) {
        return setting<std::string>(key).trySet(std::move(value));
    });

    GLOBED_VTABLE_INIT(table, setRaw, (std::string_view key, matjson::Value value) {
        return setting<matjson::Value>(key).trySet(std::move(value));
    });

    return table;
}

Result<RootApiTable*> getRootTable() {
    static auto g_table = []{
        RootApiTable table {};
        table.net = makeNetTable();
        table.game = makeGameTable();
        table.player = makePlayerTable();
        table.misc = makeMiscTable();
        table.room = makeRoomTable();
        table.module = makeModuleTable();
        table.user = makeUserTable();
        table.setting = makeSettingsTable();
        return table;
    }();

    return Ok(&g_table);
}

}
