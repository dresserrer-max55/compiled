#pragma once

#include <globed/core/data/Messages.hpp>
#include <globed/core/net/MessageListener.hpp>
#include <ui/BasePopup.hpp>

#include <cue/LoadingCircle.hpp>
#include <cue/Util.hpp>

namespace globed {

class ModUserPopup : public BasePopup, public UserInfoDelegate, public LevelManagerDelegate {
public:
    static ModUserPopup* create(int accountId);

    ~ModUserPopup();

    /// Starts loading a profile using the given query to find the user.
    void startLoadingProfile(const std::string& query);
    /// Starts loading a profile using the given account ID, strict match unlike string query.
    void startLoadingProfile(int id);

protected:
    cue::LoadingCircle* m_loadCircle = nullptr;
    MessageListener<msg::AdminFetchResponseMessage> m_listener;
    MessageListener<msg::AdminResultMessage> m_resultListener;
    std::string m_query;
    int32_t m_queryNum = 0;
    CCMenu* m_nameLayout = nullptr;
    CCMenu* m_rootMenu = nullptr;
    CCNode* m_rootLayout = nullptr;
    Ref<Button> m_roleModifyButton = nullptr;
    Ref<Button> m_banButton = nullptr;
    Ref<Button> m_whitelistButton = nullptr;
    Ref<Button> m_muteButton = nullptr;
    Ref<Button> m_roomBanButton = nullptr;

    struct Data {
        int accountId = 0;
        bool whitelisted = false;
        std::vector<uint8_t> roles;
        std::optional<UserPunishment> activeBan;
        std::optional<UserPunishment> activeRoomBan;
        std::optional<UserPunishment> activeMute;
        size_t punishmentCount;
    };

    std::optional<Data> m_data;
    GJUserScore* m_score = nullptr;

    bool init(int accountId);
    void initUi();
    void recreateRoleButton();
    void resetWhitelisted(bool whitelisted);
    void createMuteAndBanButtons();
    void fullRefresh();
    void showPunishmentPopup(UserPunishmentType type);
    void sendUpdateMessage();
    void startLoadingProfile();

    void onLoaded(const msg::AdminFetchResponseMessage& msg);
    void onUserInfoLoaded(geode::Result<GJUserScore*> res, bool sendUpdate = true);

    void getUserInfoFinished(GJUserScore* p0) override;
    void getUserInfoFailed(int p0) override;

    void loadLevelsFinished(cocos2d::CCArray* levels, char const* key, int p2) override;
    void loadLevelsFailed(char const* key, int p1) override;
};

}
