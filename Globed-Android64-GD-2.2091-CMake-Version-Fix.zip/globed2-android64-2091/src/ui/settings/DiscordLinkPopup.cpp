// the code of this popup is so shit but i feel it's too unimportant to rewrite rn

#include "DiscordLinkPopup.hpp"
#include "DiscordLinkAttemptPopup.hpp"
#include <globed/util/gd.hpp>
#include <globed/core/Constants.hpp>
#include <globed/core/PopupManager.hpp>
#include <core/net/NetworkManagerImpl.hpp>

#include <ui/Core.hpp>
#include <cue/Util.hpp>

using namespace geode::prelude;

namespace globed {

static constexpr CCSize ICON_SIZE {40.f, 40.f};

bool DiscordLinkPopup::init() {
    if (!BasePopup::init(280.f, 175.f)) return false;

    this->setTitle("Link Discord Account");

    auto gam = GJAccountManager::get();
    std::string uname = gam->m_username;
    int id = gam->m_accountID;
    cue::Icons icons = getPlayerIcons();

    m_discordBtn = Build<CCSprite>::create("discord01.png"_spr)
        .with([&](auto spr) { cue::rescaleToMatch(spr, 32.f); })
        .intoMenuItem(+[] {
            utils::web::openLinkInBrowser(globed::constant<"discord-bots">());
        })
        .pos(this->fromBottomLeft(22.f, 22.f))
        .id("discord-btn")
        .scaleMult(1.1f)
        .parent(m_buttonMenu);

    Build<CCSprite>::createSpriteName("GJ_infoIcon_001.png")
        .with([&](auto spr) { cue::rescaleToMatch(spr, 20.f); })
        .intoMenuItem([this] {
            if (m_linked) {
                globed::alert(
                    "Discord Link",
                    "In this menu you can link your <cb>Discord</c> account to your <cg>Geometry Dash</c> account.\n\n"
                    "This unlocks some benefits, such as the ability to use <cj>voice chat</c> and sync your <cb>Discord</c> roles (for <cp>Supporters</c> or <cl>Moderators</c>).\n\n"
                    "To unlink, click the <cr>Unlink</c> button below."
                );
            } else {
                globed::alert(
                    "Discord Link",
                    "In this menu you can link your <cb>Discord</c> account to your <cg>Geometry Dash</c> account.\n\n"
                    "This unlocks some benefits, such as the ability to use <cj>voice chat</c> and sync your <cb>Discord</c> roles (for <cp>Supporters</c> or <cl>Moderators</c>).\n\n"
                    "To start, you <cr>must</c> join our <cb>Discord</c> server, by clicking the button in the bottom left."
                );
            }
        })
        .pos(this->fromBottomRight(18.f, 18.f))
        .id("info-btn")
        .scaleMult(1.1f)
        .parent(m_buttonMenu);

    m_playerCard = Build<CCNode>::create()
        .anchorPoint(0.5f, 0.5f)
        .contentSize(m_size.width * 0.85f, m_size.height * 0.55f)
        .layout(RowLayout::create()->setAutoScale(false))
        .pos(this->fromTop(72.f))
        .id("player-card")
        .parent(m_mainLayer)
        .collect();

    m_playerIcon = Build(LazyPlayerIcon::create(icons))
        .with([&](auto spr) { cue::rescaleToMatch(spr, ICON_SIZE); })
        .parent(m_playerCard);

    m_dataContainer = Build<CCNode>::create()
        .layout(ColumnLayout::create()
            ->setAxisReverse(true)
            ->setAutoScale(false)
            ->setCrossAxisLineAlignment(AxisAlignment::Start)
            ->setGap(0.f)
        )
        .zOrder(10)
        .id("data-container")
        .parent(m_playerCard)
        .contentSize(0.f, 52.f)
        .collect();

    m_nameLabel = Build<Label>::create(uname.c_str(), "goldFont.fnt")
        .limitLabelWidth(m_size.width * 0.85f, 0.6f, 0.1f)
        .id("name-label")
        .parent(m_dataContainer);

    // m_idLabel = Build<CCLabelBMFont>::create(fmt::format("{}", id).c_str(), "goldFont.fnt")
    //     .scale(0.5f)
    //     .color()
    //     .parent(dataContainer);

    m_statusContainer = Build<CCNode>::create()
        .layout(RowLayout::create()->setAutoScale(false)->setGap(3.f)->setAxisAlignment(AxisAlignment::Start))
        .contentSize(140.f, 0.f)
        .id("status-container")
        .parent(m_dataContainer);

    Build<Label>::create("Status:", "bigFont.fnt")
        .scale(0.5f)
        .parent(m_statusContainer);

    m_statusLabel = Build<Label>::create("Loading...", "bigFont.fnt")
        .scale(0.5f)
        .parent(m_statusContainer);

    m_statusContainer->updateLayout();
    m_dataContainer->updateLayout();
    m_playerCard->updateLayout();

    m_background = cue::attachBackground(m_playerCard);

    auto& nm = NetworkManagerImpl::get();

    m_stateListener = nm.listen<msg::DiscordLinkStateMessage>([this](const auto& msg) {
        this->onStateLoaded(msg.id, msg.username, msg.avatarUrl);
    });

    m_oauthListener = nm.listen<msg::DiscordOauthUrlMessage>([this](const auto& msg) {
        this->onOauthUrlReceived(msg.url);
    });

    m_unlinkListener = nm.listen<msg::DiscordUnlinkResultMessage>([this](const auto& msg) {
        if (msg.success) {
            globed::alert(
                "Unlink Successful",
                "<cg>Your Discord account has been successfully unlinked!</c>"
            );
            this->onClose(nullptr);
        } else {
            globed::alertFormat(
                "Unlink Failed",
                "Failed to unlink your Discord account: <cy>{}</c>\n\nPlease contact the staff team if you need assistance.",
                msg.error
            );
            this->onClose(nullptr);
        }
    });

    this->requestState(0.f);
    // this->onStateLoaded(612930885230002208, "dank_meme01", "https://cdn.discordapp.com/avatars/612930885230002208/57793059bc19ed4cc2c36ae1c321b423.png?size=1024");

    return true;
}

void DiscordLinkPopup::onClose(CCObject*) {
    Popup::onClose(nullptr);
}

void DiscordLinkPopup::onStateLoaded(uint64_t id, const std::string& username, const std::string& avatarUrl) {
    m_linked = id != 0;

    if (id == 0) {
        if (m_activelyWaiting) return;

        m_statusLabel->setString("Unlinked");
        m_statusLabel->setColor(ccColor3B{ 255, 64, 64 });
        m_statusContainer->updateLayout();

        cue::resetNode(m_activeBtn);
        cue::resetNode(m_waitingContainer);

        m_activeBtn = Build<ButtonSprite>::create("Start", "bigFont.fnt", "GJ_button_01.png", 0.8f)
            .scale(0.95f)
            .intoMenuItem([this](auto btn) {
                NetworkManagerImpl::get().sendRequestDiscordOauth();
                cue::resetNode(m_activeBtn);
                this->addLinkingText();
            })
            .scaleMult(1.1f)
            .pos(this->fromBottom(26.f))
            .parent(m_buttonMenu);

        // without btp the Start button is unclickable :D
        cocos::handleTouchPriority(this);

        return;
    }

    m_activelyWaiting = false;
    this->unschedule(schedule_selector(DiscordLinkPopup::requestState));

    if (!username.empty()) {
        m_nameLabel->setString(username.c_str());
        m_statusLabel->setString("Linked");
        m_statusLabel->setColor(ccColor3B{ 69, 255, 23 });
    } else {
        // linked, but the server for some reason cannot obtain username & avatar
        m_statusLabel->setString("Linked (?)");
        m_statusLabel->setColor(ccColor3B{ 211, 255, 51 });
    }

    m_statusContainer->updateLayout();

    cue::resetNode(m_idLabel);
    cue::resetNode(m_background);
    cue::resetNode(m_waitingContainer);
    m_waitingLabel1 = nullptr;
    m_waitingLabel2 = nullptr;
    cue::resetNode(m_avatar);
    cue::resetNode(m_activeBtn);

    m_dataContainer->updateLayout();

    // only replace the avatar if we actually got a link
    if (!avatarUrl.empty()) {
        m_playerIcon->setVisible(false);
        m_avatar = Build(LazySprite::create(ICON_SIZE))
            .parent(m_playerCard);
        m_avatar->setAutoResize(true);
        m_avatar->loadFromUrl(convertAvatarUrl(avatarUrl));
        m_avatar->setLoadCallback([this](Result<> res) {
            if (res.isOk()) {
                // nothing
            } else {
                // show player icon
                m_playerIcon->setVisible(true);
                cue::resetNode(m_avatar);
            }
        });
    }

    m_playerCard->updateLayout();

    m_background = cue::attachBackground(m_playerCard);

    // unlink button
    m_activeBtn = Build<ButtonSprite>::create("Unlink", "bigFont.fnt", "GJ_button_01.png", 0.8f)
        .scale(0.9f)
        .intoMenuItem([this](auto btn) {
            globed::confirmPopup(
                "Confirm Unlink",
                "Are you sure you want to unlink your <cb>Discord</c> account? You may lose access to your roles and voice chat.",
                "Cancel", "Ok",
                [this, btn](auto) {
                    NetworkManagerImpl::get().sendRequestDiscordUnlink();
                    btn->removeFromParent();
                    this->startWaitingForUnlink();
                }
            );
        })
        .scaleMult(1.1f)
        .pos(this->fromBottom(26.f))
        .parent(m_buttonMenu);

    // without btp the button is unclickable :D
    cocos::handleTouchPriority(this);
}

void DiscordLinkPopup::addLinkingText() {
    m_waitingContainer = Build(ColumnContainer::create(6.f))
        .pos(this->fromCenter(0.f, -30.f))
        .id("waiting-container")
        .parent(m_mainLayer)
        .collect();

    m_waitingLabel1 = Build<Label>::create("Requesting URL...", "bigFont.fnt")
        .scale(0.5f)
        .id("waiting-label1")
        .parent(m_waitingContainer);

    m_waitingLabel2 = Build<Label>::create("", "bigFont.fnt")
        .id("waiting-label2")
        .limitLabelWidth(m_size.width * 0.8f, 0.4f, 0.1f)
        .parent(m_waitingContainer);

    m_waitingContainer->updateLayout();
}

// void DiscordLinkPopup::onAttemptReceived(uint64_t id, const std::string& username, const std::string& avatarUrl) {
//     auto popup = DiscordLinkAttemptPopup::create(id, username, avatarUrl);
//     popup->setCallback([this, id](bool confirm) {
//         NetworkManagerImpl::get().sendDiscordLinkConfirm(id, confirm);

//         if (confirm) {
//             this->startWaitingForRefresh();
//         }
//     });
//     popup->show();
// }

void DiscordLinkPopup::onOauthUrlReceived(ZStringView url) {
    utils::web::openLinkInBrowser(url);
    this->startWaitingForRefresh();

    if (!m_waitingLabel1 || !m_waitingLabel2) return;

    m_waitingLabel1->setText("Open your browser!");
    m_waitingLabel2->setText("Waiting for confirmation...");

    cue::resetNode(m_activeBtn);
    m_activeBtn = Build<ButtonSprite>::create("Copy Link", "bigFont.fnt", "GJ_button_01.png", 0.7f)
        .scale(0.8f)
        .intoMenuItem([url = std::string{url}](auto btn) {
            utils::clipboard::write(url);
            globed::toastSuccess("Link copied to clipboard! Open it in your browser to continue.");
        })
        .scaleMult(1.1f)
        .pos(this->fromBottom(22.f))
        .parent(m_buttonMenu);

    // without btp the button is unclickable :D
    cocos::handleTouchPriority(this);
}

void DiscordLinkPopup::startWaitingForRefresh() {
    m_activelyWaiting = true;
    this->schedule(schedule_selector(DiscordLinkPopup::requestState), 1.0f);
}

void DiscordLinkPopup::startWaitingForUnlink() {
    m_activelyWaiting = true;

    auto circle = Build(cue::LoadingCircle::create())
        .scale(0.6f)
        .pos(this->fromBottom(24.f))
        .parent(m_mainLayer)
        .collect();
    circle->fadeIn();
    m_waitingContainer = circle;
}

void DiscordLinkPopup::requestState(float) {
    NetworkManagerImpl::get().sendGetDiscordLinkState();
}

DiscordLinkPopup* DiscordLinkPopup::create() {
    auto ret = new DiscordLinkPopup;
    if (ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

}