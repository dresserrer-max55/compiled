#include "Item.hpp"
#include "FileUtils.hpp"
#include "OpenGL.hpp"
#include "PreloadManager.hpp"
#include "spriteframes.hpp"
#include <prevter.imageplus/include/events.hpp>
#include <bit>

#ifdef GEODE_IS_WINDOWS
# include <asp/simd/CPUFeatures.hpp>
# include <immintrin.h>
#endif

using namespace geode::prelude;
using enum std::memory_order;


namespace globed {

struct ScratchBuffer {
    std::unique_ptr<uint8_t[]> m_data;
    size_t m_cap = 0;

    uint8_t* reserve(size_t required) {
        if (required == 0) return nullptr;

        if (m_cap < required) {
            m_cap = std::bit_ceil(required); // next power of 2
            m_data = std::make_unique<uint8_t[]>(m_cap);
        }
        return m_data.get();
    }
};

static asp::SpinLock<> cocosLock;
static thread_local ScratchBuffer g_scratch;

static bool shouldUsePBO() {
    static bool should = g_opengl.supportsPBO && globed::setting<bool>("core.preload.use-pbos");
    return should;
}

bool canDirectDecode() {
    static bool can = shouldUsePBO() && imgp::isAvailable() && globed::setting<bool>("core.preload.use-direct-decode");
    return can;
}

PreloadItemState::PreloadItemState(PreloadItemState&& other) noexcept
    : m_item(std::move(other.m_item)),
      m_path(std::move(other.m_path)),
      m_batchState(std::move(other.m_batchState)),
      m_image(std::move(other.m_image)),
      m_texture(std::move(other.m_texture)),
      m_pbo(std::exchange(other.m_pbo, 0)),
      m_tex(std::exchange(other.m_tex, 0)),
      m_state(other.m_state.load(relaxed))
{}

bool PreloadItemState::process() {
    switch (this->state()) {
        case ItemStateEnum::Initial: {
            g_opengl.initialize();
            this->enqueueImageDecode();
        } break;

        case ItemStateEnum::HeaderParsed: {
            // We parsed the header and obtained with and height of the image,
            // we are now ready to allocate a PBO and decode the image straight into it
            this->enqueuePBOCreation();
        } break;

        case ItemStateEnum::ImageReady: {
            // Image is now ready, we need to initialize the texture
            // This again differs by whether we support PBOs or not
            if (shouldUsePBO()) {
                this->enqueuePBOCreation();
            } else {
                if (!this->createTexture()) {
                    log::warn("PreloadManager: failed to create texture for '{}'", m_path);
                    m_state.store(ItemStateEnum::Failed, relaxed);
                    return false;
                }

                // texture is now ready!
                m_state.store(ItemStateEnum::TextureReady, relaxed);
                return true;
            }
        } break;

        case ItemStateEnum::PboReady: {
            // The PBO is ready and contains all image data, we just need to finalize it into a texture.
            this->finalizePBO();
            m_state.store(ItemStateEnum::TextureReady, relaxed);
            return true;
        } break;

        case ItemStateEnum::TextureReady: {
            // Texture is ready and was added to texture cache, now we need to add sprite frames
            this->initSpriteFrames();
        } break;

        case ItemStateEnum::Failed: break;
        default: std::unreachable();
    }

    return false;
}

void PreloadItemState::invokeCallback(std::optional<ItemStateEnum> state ) {
    if (state) {
        m_state.store(*state, relaxed);
    }
    m_batchState->callback(*m_batchState, *this);
}

void PreloadItemState::cleanup() {
    // here we do cleanup that must happen on main thread
    if (m_tex) {
        glDeleteTextures(1, &m_tex);
        m_tex = 0;
    }
    if (m_pbo) {
        glDeleteBuffers(1, &m_pbo);
        m_pbo = 0;
    }
}

void PreloadItemState::enqueueImageDecode() {
    auto& pool = *m_batchState->pool;

    pool.pushTask([this] {
        // Initial state - load image into memory, then kick off the decoding process
        unsigned long filesize = 0;
        auto buffer = getFileDataThreadSafe(m_path.c_str(), "rb", &filesize);

        if (!buffer || filesize == 0) {
            log::warn("PreloadManager: could not read file '{}'", m_path);
            this->invokeCallback(ItemStateEnum::Failed);
            return;
        }

        m_rawData = std::move(buffer);
        m_rawSize = filesize;

        if (canDirectDecode()) {
            // try to parse only the image header, this may not work if imageplus is outdated
            auto res = imgp::decode::pngHeader(m_rawData.get(), m_rawSize);

            if (res) {
                auto hdr = std::move(res).unwrap();
                m_width = hdr.width;
                m_height = hdr.height;

                this->invokeCallback(ItemStateEnum::HeaderParsed);
                return;
            } else {
                log::warn("Failed to decode PNG header: {}, falling back to full decode", res.unwrapErr());
            }
        }

        m_image = Ref<CCImage>::adopt(new CCImage());
        if (!m_image->initWithImageData(m_rawData.get(), m_rawSize, cocos2d::CCImage::kFmtPng)) {
            m_image = nullptr;
            m_rawData.reset();
            log::warn("PreloadManager: failed to init image '{}'", m_path);
            this->invokeCallback(ItemStateEnum::Failed);
            return;
        }

        m_rawData.reset();
        m_width = m_image->m_nWidth;
        m_height = m_image->m_nHeight;
        this->invokeCallback(ItemStateEnum::ImageReady);
    });
}

bool PreloadItemState::createTexture() {
    m_texture = Ref<CCTexture2D>::adopt(new CCTexture2D());
    if (!m_texture->initWithImage(m_image)) {
        m_texture = nullptr;
        return false;
    }
    return true;
}

static void checkGL(std::string_view where) {
    GLenum err;
    while ((err = glGetError()) != GL_NO_ERROR) {
        log::error("GL error at {}: 0x{:X}", where, err);
    }
}

static void checkGLDbg(std::string_view where) {
#ifdef GLOBED_DEBUG
    checkGL(where);
#endif
}

static void clearGLError() {
    while (glGetError() != GL_NO_ERROR);
}

static void premultiplyInto(const void* source, void* dest, size_t bytes);

void PreloadItemState::enqueuePBOCreation() {
    GLOBED_DEBUG_ASSERT(!m_tex && !m_pbo);

    int64_t width = m_width;
    int64_t height = m_height;
    int64_t byteSize = width * height * 4;

    // some cocos code leaves an error for us
    clearGLError();

    glGenTextures(1, &m_tex);
    glGenBuffers(1, &m_pbo);

    glBindTexture(GL_TEXTURE_2D, m_tex);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    if (g_opengl.supportsImmutableTex) {
        g_opengl.pglTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8, width, height);
        checkGLDbg("glTexStorage2D");
    } else {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        checkGLDbg("glTexImage2D");
    }

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_pbo);
    glBufferData(GL_PIXEL_UNPACK_BUFFER, byteSize, nullptr, GL_STREAM_DRAW);

    void* ptr = g_opengl.pglMapBufferRange(GL_PIXEL_UNPACK_BUFFER, 0, byteSize, GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_BUFFER_BIT);
    checkGLDbg("glMapBufferRange");

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
    glBindTexture(GL_TEXTURE_2D, 0);

    if (!ptr) {
        utils::terminate(
            "PreloadManager: failed to map a PBO, likely ran out of memory! "
            "Please report this to the Globed developers and include the latest game log (not crashlog!)"
        );
    }

    m_batchState->pool->pushTask([ptr, this] mutable {
        int64_t byteSize = (int64_t)m_width * (int64_t)m_height * 4;
        if (m_image) {
            std::memcpy(ptr, m_image->m_pData, byteSize);
            m_image = nullptr; // no longer needed
        } else {
            // decode the image into a scratch buffer
            auto sbuf = g_scratch.reserve(byteSize);
            auto res = imgp::decode::pngInto(m_rawData.get(), m_rawSize, sbuf, byteSize);
            m_rawData.reset();

            if (!res) {
                log::warn("PreloadManager: failed to decode image '{}' into PBO: {}", m_path, res.unwrapErr());
                this->invokeCallback(ItemStateEnum::Failed);
                return;
            }

            auto bytes = res.unwrap();
            GLOBED_DEBUG_ASSERT(bytes == (size_t)byteSize);
            // log::debug("{}: decoded: {} png, {} decoded, {} expected", m_path, m_rawSize, bytes, byteSize);

            // now premultiply alpha and write into the pbo
            premultiplyInto(sbuf, ptr, byteSize);
        }

        // notify main thread
        this->invokeCallback(ItemStateEnum::PboReady);
    });
}

void PreloadItemState::finalizePBO() {
    // auto now = asp::Instant::now();
    clearGLError();
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_pbo);
    GLboolean ok = glUnmapBuffer(GL_PIXEL_UNPACK_BUFFER);
    GLOBED_ASSERT(ok);
    glBindTexture(GL_TEXTURE_2D, m_tex);

    int64_t w = m_width, h = m_height;
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    checkGL("glTexSubImage2D");

    // unbind texture & pbo, delete the pbo
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
    glDeleteBuffers(1, &m_pbo);
    m_pbo = 0;

    m_texture = Ref<CCTexture2D>::adopt(new CCTexture2D());
    auto& texture = m_texture;
    texture->m_uName = std::exchange(m_tex, 0);
    texture->m_tContentSize = CCSize(w, h);
    texture->m_uPixelsWide = w;
    texture->m_uPixelsHigh = h;
    texture->m_ePixelFormat = kCCTexture2DPixelFormat_RGBA8888;
    texture->m_bHasPremultipliedAlpha = true;
    texture->m_bHasMipmaps = false;

    // this is  weird
    texture->m_fMaxS = 1.f;
    texture->m_fMaxT = 1.f;

    texture->setShaderProgram(CCShaderCache::sharedShaderCache()->programForKey(kCCShader_PositionTexture));
}

void PreloadItemState::initSpriteFrames() {
    auto& pool = *m_batchState->pool;
    pool.pushTask([this] {
        auto result = this->_initSpriteFramesInner();

        if (result == SpriteFrameInitResult::Success) {
            m_batchState->completedItems.fetch_add(1, relaxed);
            this->invokeCallback(ItemStateEnum::Ready);
        } else if (result == SpriteFrameInitResult::Failed) {
            this->invokeCallback(ItemStateEnum::Failed);
        }
        // don't invoke callback if pending
    });
}

SpriteFrameInitResult PreloadItemState::_initSpriteFramesInner() {
    auto texCache = CCTextureCache::get();
    auto sfCache = CCSpriteFrameCache::get();
    auto& pm = PreloadManager::get();

    if (!m_texture) {
        log::warn("PreloadManager: texture for '{}' was not initialized", m_path);
        return SpriteFrameInitResult::Failed;
    }

    StringBuffer<> buf;
    buf.append("{}.plist", m_item.image);
    auto plistKey = buf.view();

    if (pm.m_loadedFrames.lock()->contains(plistKey)) {
        log::trace("PreloadManager: already loaded frames for '{}', skipping", m_item.image);
        return SpriteFrameInitResult::Success;
    }

    auto pathsv = std::string_view{m_path};
    StringBuffer<> fullPlistPath;
    fullPlistPath.append(pathsv.substr(0, pathsv.find(".png")));
    fullPlistPath.append(".plist");

    // read the file
    unsigned long plistSize;
    auto plistData = getFileDataThreadSafe(fullPlistPath.c_str(), "rb", &plistSize);
    if (!plistData || plistSize == 0) {
        log::info("PreloadManager: can't load {}, trying slower fallback option", fullPlistPath.view());
        std::string_view attemptedPlist = relativizeIconPath(fullPlistPath.view());
        auto fallbackPath = pm.fullPathForFilename(attemptedPlist);
        plistData = getFileDataThreadSafe(fallbackPath.c_str(), "rb", &plistSize);
    }

    if (!plistData || plistSize == 0) {
        log::warn("PreloadManager: failed to find the plist for '{}'", m_path);

        // remove the texture from the cache
        geode::queueInMainThread([path = m_path] {
            CCTextureCache::get()->m_pTextures->removeObjectForKey(path);
        });
        return SpriteFrameInitResult::Failed;
    }

    auto res = parseSpriteFrames(plistData.get(), plistSize);
    if (!res) {
        log::warn("PreloadManager: failed to parse sprite frames for '{}': {}", m_path, res.unwrapErr());
        return SpriteFrameInitResult::Failed;
    }

    pm.m_loadedFrames.lock()->insert(std::string{plistKey});

    if (m_batchState->m_blockingMode) {
        // blocking mode, just add sprite frames here under the mutex
        auto lock = cocosLock.lock();
        addSpriteFrames(*std::move(res).unwrap(), m_texture);
        return SpriteFrameInitResult::Success;
    }

    // non-blocking mode, using a mutex will be unsafe due to main thread still being alive, so qimt
    geode::queueInMainThread([this, spf = std::move(res).unwrap(), pdata = std::move(plistData)] {
        addSpriteFrames(*spf, m_texture);

        // done!
        this->invokeCallback(ItemStateEnum::Ready);
    });

    return SpriteFrameInitResult::Pending;
}

bool BatchPreloadState::doProcess() {
    if (auto req = texRequests.tryPop()) {
        auto& item = **req;

        // if the item is not ready/failed, immediately advance the state machine forward
        auto state = item.state();
        if (state != ItemStateEnum::TextureReady && state != ItemStateEnum::Failed && state != ItemStateEnum::Ready) {
            if (!item.process()) {
                // not yet ready, result will be posted to main thread later
                return true;
            }

            // item state has changed now!
            state = item.state();
        }

        switch (state) {
            // ready state - nothing to do
            case ItemStateEnum::Ready: break;

            // failure state - perform cleanup and skip
            case ItemStateEnum::Failed: {
                item.cleanup();
            } break;

            // textureready state - the texture is complete, enqueue sprite frames task which is the final one
            case ItemStateEnum::TextureReady: {
                this->insertTexture(item);
                item.process();
            } break;

            // this should not be reached in practice, process() must only return true if the state is ready or failed
            default: GLOBED_ASSERT(false);
        }

        return true;
    }
    return false;
}

void BatchPreloadState::insertTexture(PreloadItemState& state) {
    auto texCache = CCTextureCache::get();
    texCache->m_pTextures->setObject(state.m_texture, state.m_path);

    // cache the icon texture
    PreloadManager::get().setCachedIcon((int) state.m_item.iconType, state.m_item.iconId, state.m_texture);
    this->initedTextures.fetch_add(1, std::memory_order::relaxed);
}

bool BatchPreloadState::hasFinished() {
    if (texRequests.empty()) {
        // verify that everything is truly done
        for (auto& item : this->items) {
            auto st = item.state();
            if (st != ItemStateEnum::Ready && st != ItemStateEnum::Failed) {
                // log::debug("PreloadManager: looping again, item {} is incomplete (state {})", item.m_path, (int)st);
                return false;
            }
        }

        return true;
    }

    return false;
}

void BatchPreloadState::cleanup() {
    for (auto& item : this->items) {
        item.cleanup();
    }
    this->items.clear();
    this->callback = {};
    this->completionCallback = {};
}

void BatchPreloadState::maybeEnqueueMTUpdate() {
    // queue update if not queued already
    if (this->queuedUpdate.exchange(true, std::memory_order::acq_rel)) return;

    geode::queueInMainThread([self = this->sharedFromThis()] {
        self->queuedUpdate.store(false, std::memory_order::release);
        while (self->doProcess());

        // check if we have finished
        if (self->hasFinished()) {
            if (self->completionCallback) self->completionCallback();
            self->cleanup();
        }
    });
}

static void premultiplyIntoScalar(const void* source, void* dest, size_t bytes) {
    size_t pixels = bytes / 4;
    auto src = static_cast<const uint8_t*>(source);
    auto dst = static_cast<uint8_t*>(dest);

    for (size_t i = 0; i < pixels; i++) {
        uint8_t r = src[0];
        uint8_t g = src[1];
        uint8_t b = src[2];
        uint8_t a = src[3];

        dst[0] = (r * a) / 255;
        dst[1] = (g * a) / 255;
        dst[2] = (b * a) / 255;
        dst[3] = a;

        src += 4;
        dst += 4;
    }
}

#ifdef GEODE_IS_WINDOWS
static __attribute__((target("ssse3"))) void premultiplyIntoSSSE3(const void* source, void* dest, size_t bytes) {
    size_t const max_simd_pixel = bytes / sizeof(__m128i) * sizeof(__m128i);

    __m128i const mask_alphha_color_odd_255 = _mm_set1_epi32(static_cast<int>(0xff000000));
    __m128i const div_255 = _mm_set1_epi16(static_cast<short>(0x8081));

    __m128i const mask_shuffle_alpha = _mm_set_epi32(0x0f800f80, 0x0b800b80, 0x07800780, 0x03800380);
    __m128i const mask_shuffle_color_odd = _mm_set_epi32(static_cast<int>(0x80800d80), static_cast<int>(0x80800980), static_cast<int>(0x80800580), static_cast<int>(0x80800180));

    const __m128i* src = reinterpret_cast<const __m128i*>(source);
    __m128i* dst = reinterpret_cast<__m128i*>(dest);
    __m128i color, alpha, color_even, color_odd;

    for (size_t i = 0; i < max_simd_pixel; i += sizeof(__m128i)) {
        color = _mm_loadu_si128(src);

        alpha = _mm_shuffle_epi8(color, mask_shuffle_alpha);

        color_even = _mm_slli_epi16(color, 8);
        color_odd = _mm_shuffle_epi8(color, mask_shuffle_color_odd);
        color_odd = _mm_or_si128(color_odd, mask_alphha_color_odd_255);
//            color_odd = _mm_blendv_epi8(color, _mm_set_epi32(0xff000000, 0xff000000, 0xff000000, 0xff000000), _mm_set_epi32(0x80800080, 0x80800080, 0x80800080, 0x80800080));

        color_odd = _mm_mulhi_epu16(color_odd, alpha);
        color_even = _mm_mulhi_epu16(color_even, alpha);

        color_odd = _mm_srli_epi16(_mm_mulhi_epu16(color_odd, div_255), 7);
        color_even = _mm_srli_epi16(_mm_mulhi_epu16(color_even, div_255), 7);

        color = _mm_or_si128(color_even, _mm_slli_epi16(color_odd, 8));

        _mm_storeu_si128(dst, color);

        src++;
        dst++;
    }

    size_t remBytes = bytes - max_simd_pixel;
    premultiplyIntoScalar(
        static_cast<const uint8_t*>(source) + max_simd_pixel,
        static_cast<uint8_t*>(dest) + max_simd_pixel,
        remBytes
    );
}
#endif

void premultiplyInto(const void* source, void* dest, size_t bytes) {
#ifdef GEODE_IS_WINDOWS
    // apparently, some people are able to run this game on cpus from 2010 that do not support ssse3
    static bool support = asp::simd::getFeatures().ssse3;
    if (support) {
        premultiplyIntoSSSE3(source, dest, bytes);
        return;
    }
#endif
    premultiplyIntoScalar(source, dest, bytes);
}

}
