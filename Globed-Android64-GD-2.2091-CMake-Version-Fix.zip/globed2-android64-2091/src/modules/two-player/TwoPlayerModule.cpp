#include "TwoPlayerModule.hpp"
#include "ui/LinkRequestPopup.hpp"
#include <globed/core/game/RemotePlayer.hpp>
#include <globed/core/RoomManager.hpp>
#include <globed/core/PopupManager.hpp>
#include <globed/util/mh.hpp>
#include <core/hooks/GJBaseGameLayer.hpp>
#include <core/net/NetworkManagerImpl.hpp>
#include <modules/ui/popups/UserListPopup.hpp>

#include <UIBuilder.hpp>

using namespace geode::prelude;

namespace globed {

TwoPlayerModule::TwoPlayerModule() {
    TwoPlayerLinkEvent::listen([this](const auto& msg, const auto& opts) {
        this->handleLinkEvent(msg, opts.sender);
    }).leak();

    TwoPlayerUnlinkEvent::listen([this](const auto& msg, const auto& opts) {
        this->handleUnlinkEvent(msg, opts.sender);
    }).leak();

    UserListPopupSetupEvent{}.listen([this](cocos2d::CCNode* container, int accountId, bool myself, UserListPopup* popup) {
        this->onUserlistSetup(container, accountId, myself, popup);
    }).leak();
}

void TwoPlayerModule::onDisabled() {
    m_linkedPlayer.reset();
    m_ignoreNoclip = false;
    m_isPlayer2 = false;
    m_linkAttempt.reset();
    m_linkedRp = nullptr;
}

void TwoPlayerModule::onJoinLevel(GlobedGJBGL* gjbgl, GJGameLevel* level, bool editor) {
    // if 2p mode is disabled, disable the module for this level
    if (!RoomManager::get().getSettings().twoPlayerMode) {
        (void) this->disable();
    } else {
        // safe mode is forced in 2 player mode
        log::info("2p mode - enabling safe mode for the level");
        gjbgl->setPermanentSafeMode();

        // enable low latency interpolator
        auto& lerper = gjbgl->m_fields->m_interpolator;
        gjbgl->toggleCullingEnabled(false);
        gjbgl->toggleExtendedData(true);
        lerper.setLowLatencyMode(true);

        if (mh::isHackEnabled(mh::MH_FRAME_EXTRAPOLATION)) {
            mh::setHackEnabled(mh::MH_FRAME_EXTRAPOLATION, false);
            PopupManager::get().alert(
                "Globed Warning",
                "<cy>Frame Extrapolation</c> in <cy>Mega Hack</c> is not compatible with this mode, so it has been disabled."
            ).showQueue();
        }
    }
}

void TwoPlayerModule::onPlayerDeath(GlobedGJBGL* gjbgl, RemotePlayer* player, const PlayerDeath& death) {
    auto& mod = TwoPlayerModule::get();

    if (death.isReal && player && player->id() == m_linkedPlayer) {
        this->causeLocalDeath(gjbgl);
    }
}

void TwoPlayerModule::onPlayerRespawn(GlobedGJBGL* gjbgl, RemotePlayer* player) {
    if (m_isPlayer2 && player && player->id() == m_linkedPlayer) {
        // respawn now
        gjbgl->causeLocalRespawn();
    }
}

void TwoPlayerModule::onUserlistSetup(cocos2d::CCNode* container, int accountId, bool myself, UserListPopup* popup) {
    if (myself) return;

    // if we are already linked, show only an unlink button on the linked player
    if (m_linkedPlayer) {
        if (accountId != *m_linkedPlayer) {
            return;
        }

        Build<CCSprite>::createSpriteName("gj_linkBtnOff_001.png")
            .scale(0.8f)
            .intoMenuItem([this, popup] {
                this->unlink();
                popup->hardRefresh();
            })
            .id("2p-unlink")
            .parent(container);

        return;
    }

    // otherwise, show a link button on all players

    Build<CCSprite>::createSpriteName("gj_linkBtn_001.png")
        .scale(0.8f)
        .intoMenuItem([accountId, popup] {
            LinkRequestPopup::create(accountId, popup)->show();
        })
        .id("2p-unlink")
        .parent(container);
}

void TwoPlayerModule::onPlayerLeave(GlobedGJBGL* gjbgl, int accountId) {
    if (accountId == m_linkedPlayer) {
        this->unlink();
    }
}

void TwoPlayerModule::onLocalPlayerDeath(GlobedGJBGL* gjbgl, bool real) {
    // don't respawn immediately if we are not the main player, instead wait for the main player to respawn us
    if (real && m_isPlayer2) {
        gjbgl->cancelLocalRespawn();
    }
}

void TwoPlayerModule::onUpdate(GlobedGJBGL* gjbgl, float dt) {
    auto ghost = gjbgl->m_fields->m_ghost.get();
    PlayerObject* noclipFor = this->isPlayer2() ? gjbgl->m_player1 : gjbgl->m_player2;
    PlayerObject* noclipForVP = this->isPlayer2() ? ghost->player1() : ghost->player2();
    auto pobj = this->getLinkedPlayerObject(!this->isPlayer2());
    if (!noclipFor || !pobj) return;

    auto& lerper = gjbgl->m_fields->m_interpolator;
    lerper.setCameraCorrections(!this->isPlayer2());

    this->updateFromLinkedPlayer(noclipFor, pobj);
    if (!gjbgl->m_gameState.m_isDualMode && this->isPlayer2()) {
        gjbgl->setCameraFollowPlayer(pobj);
        gjbgl->setSpectating(true);
    } else {
        gjbgl->setCameraFollowPlayer(nullptr);
        gjbgl->setSpectating(false);
    }

    // hide player1 if we are player 2
    setPlayerHidden(gjbgl->m_player1, this->isPlayer2());

    setPlayerHidden(noclipFor, true);
    setPlayerHidden(noclipForVP, true);
}

void TwoPlayerModule::updateFromLinkedPlayer(PlayerObject* local, VisualPlayer* linked) {
    bool shouldUpdateArt =
        (local->m_gravity != linked->m_gravity)
        || (local->m_isUpsideDown != linked->m_isUpsideDown)
        || local->m_isGoingLeft != linked->m_isGoingLeft;

    auto pos = linked->getLastPosition();
    local->m_position = pos;
    local->m_yVelocity = linked->m_yVelocity;
    local->m_platformerXVelocity = linked->m_platformerXVelocity;
    local->m_isOnGround = linked->m_isOnGround;
    local->m_isGoingLeft = linked->m_isGoingLeft;
    local->m_isAccelerating = linked->m_isAccelerating;
    local->m_accelerationOrSpeed = linked->m_accelerationOrSpeed;
    local->m_fallStartY = linked->m_fallStartY;
    local->m_gravity = linked->m_gravity;
    local->m_gravityMod = linked->m_gravityMod;
    local->m_isOnGround2 = linked->m_isOnGround2;
    local->m_touchedPad = linked->m_touchedPad;
    local->m_isUpsideDown = linked->m_isUpsideDown;
    local->m_maybeIsFalling = linked->m_maybeIsFalling;
    local->m_fallSpeed = linked->m_fallSpeed;
    local->m_isOnGround4 = linked->m_isOnGround4;
    local->setPosition(pos);

    // TODO: doesnt work
    // if (shouldUpdateArt) {
    //     this->updatePlayerArt();
    // }
}

bool TwoPlayerModule::link(int id, bool player2) {
    if (m_linkAttempt || m_linkedPlayer) {
        globed::toastError("Cannot link while already linked to a player");
        return false;
    }

    m_linkAttempt = id;

    // send an link event
    this->sendLinkEventTo(id, player2);

    return true;
}

void TwoPlayerModule::cancelLink() {
    m_linkAttempt.reset();
}

bool TwoPlayerModule::isLinked() {
    return m_linkedPlayer.has_value();
}

bool TwoPlayerModule::isPlayer2() {
    return m_isPlayer2;
}

bool TwoPlayerModule::waitingForLink() {
    return m_linkAttempt.has_value();
}

VisualPlayer* TwoPlayerModule::getLinkedPlayerObject(bool player2) {
    if (!m_linkedRp) return nullptr;

    return player2 ? m_linkedRp->player2() : m_linkedRp->player1();
}

bool& TwoPlayerModule::ignoreNoclip() {
    return m_ignoreNoclip;
}

void TwoPlayerModule::causeLocalDeath(GJBaseGameLayer* gjbgl) {
    m_ignoreNoclip = true;
    GlobedGJBGL::get(gjbgl)->killLocalPlayer();
    m_ignoreNoclip = false;
}

void TwoPlayerModule::unlink(bool silent) {
    if (!m_linkedPlayer) return;

    int id = *m_linkedPlayer;
    m_linkedPlayer.reset();

    if (!silent) {
        // send an unlink event
        this->sendUnlinkEventTo(id);
    }
}

void TwoPlayerModule::sendUnlinkEventTo(int id) {
    TwoPlayerUnlinkEvent{}.send(id);
}

void TwoPlayerModule::sendLinkEventTo(int id, bool player2) {
    // in the event, send what THEY will become, aka if we are p2, send that they will be p1
    TwoPlayerLinkEvent{ player2 }.send(id);
}

void TwoPlayerModule::linkSuccess(int id, bool player2) {
    m_linkedPlayer = id;
    m_isPlayer2 = player2;
    m_linkAttempt.reset();

    m_linkedRp = GlobedGJBGL::get()->getPlayer(id);
    if (!m_linkedRp) {
        globed::toastError("(Globed) Failed to find player by ID: {}", id);
        this->unlink();
    }
}

void TwoPlayerModule::handleLinkEvent(const TwoPlayerLinkEvent& event, int playerId) {
    // are we already linked? if so, send an unlink if it's a different player (rejecting the link attempt)
    if (m_linkedPlayer) {
        if (*m_linkedPlayer != playerId) {
            this->sendUnlinkEventTo(playerId);
        }
        return;
    }

    // are we currently trying to link? check if it's the right user
    if (m_linkAttempt) {
        if (*m_linkAttempt != playerId) {
            this->sendUnlinkEventTo(playerId);
            return;
        }

        // successful link!
        this->linkSuccess(playerId, !event.player1);
        return;
    }

    // if we are not currently trying to link, show a popup to the user, asking if they agree to link
    std::string username;

    if (auto pl = GlobedGJBGL::get()) {
        if (auto player = pl->getPlayer(playerId)) {
            if (player->isDataInitialized()) {
                username = player->displayData().username;
            }
        }
    }

    if (username.empty()) {
        username = fmt::format("Unknown ({})", playerId);
    }

    globed::quickPopup(
        "Note",
        fmt::format("<cg>{}</c> wants to link with you. You will be playing as the <cy>{} player</c>. Agree to link?", username, event.player1 ? "first" : "second"),
        "Cancel",
        "Agree",
        [this, event, playerId](auto, bool agree) {
            if (!agree) {
                this->sendUnlinkEventTo(playerId);
            } else {
                // successful link! make sure to send confirmation event
                this->sendLinkEventTo(playerId, !event.player1);
                this->linkSuccess(playerId, !event.player1);
            }
        }
    );
}

void TwoPlayerModule::handleUnlinkEvent(const TwoPlayerUnlinkEvent& event, int playerId) {
    if (m_linkedPlayer == playerId) {
        this->unlink(true);
        return;
    }

    // if this is from the current link attempt, cancel the attempt
    if (m_linkAttempt == playerId) {
        m_linkAttempt.reset();
    }
}

}
