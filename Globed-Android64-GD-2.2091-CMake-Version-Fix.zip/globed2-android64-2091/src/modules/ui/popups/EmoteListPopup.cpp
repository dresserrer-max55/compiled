#include "EmoteListPopup.hpp"
#include <globed/core/PopupManager.hpp>
#include <globed/core/EmoteManager.hpp>
#include <globed/util/FunctionQueue.hpp>
#include <core/hooks/GJBaseGameLayer.hpp>

#include <Geode/ui/GeodeUI.hpp>
#include <UIBuilder.hpp>
#include <asp/time/Instant.hpp>

using namespace geode::prelude;
using namespace asp::time;

namespace globed {

static constexpr CCSize LIST_SIZE = {280.f, 130.f};
static constexpr float CELL_HEIGHT = 40.f;
static constexpr CCSize CELL_SIZE{LIST_SIZE.width, CELL_HEIGHT};
static constexpr size_t EMOTES_PER_PAGE = 18;

static bool isEmoteKeyBound(uint32_t slot) {
    auto key = fmt::format("keybind-emote-{}", slot);
    return !Mod::get()->getSettingValue<std::vector<Keybind>>(key).empty();
}

static bool isAnyEmoteKeyBound() {
    for (uint32_t i = 0; i < 8; i++) {
        if (isEmoteKeyBound(i)) {
            return true;
        }
    }
    return false;
}

bool EmoteListPopup::init() {
    if (!BasePopup::init(360.f, 280.f)) return false;

    this->setTitle("Emotes");
    m_title->setPosition(this->fromTop(15.f));

    m_noElasticity = true;

    auto& allEmotes = EmoteManager::get().getEmotes();
    m_maxPages = (allEmotes.size() + EMOTES_PER_PAGE - 1) / EMOTES_PER_PAGE;

    for (int i = 0; i < 8; i++) {
        auto emote = globed::value<uint32_t>(fmt::format("core.ui.emote-slot-{}", i)).value_or(0);
        m_favoriteEmoteIds.push_back(emote);
    }

    m_pageLabel = Build<Label>::create(fmt::format("Page {} of {}", m_selectedPage + 1, m_maxPages), "bigFont.fnt")
        .anchorPoint(0.5f, 0.5f)
        .pos(this->fromTop(30.f))
        .scale(0.3f)
        .zOrder(30)
        .parent(m_mainLayer);

    m_list = Build(cue::ListNode::create(LIST_SIZE, cue::Brown, cue::ListBorderStyle::Comments))
        .anchorPoint(0.5f, 1.f)
        .pos(this->fromTop(40.f))
        .parent(m_mainLayer);

    m_list->updateLayout();

    m_emoteMenu = Build<CCMenu>::create()
        .pos(this->fromTop(45.f))
        .contentSize({245.f, LIST_SIZE.height - 10.f})
        .anchorPoint(0.5f, 1.f)
        .layout(AxisLayout::create()
            ->setAxis(Axis::Row)
            ->setAxisAlignment(AxisAlignment::Start)
            ->setAutoScale(false)
            ->setGrowCrossAxis(true)
            ->setGap(7.f)
        )
        .id("emote-grid")
        .parent(m_mainLayer);

    this->loadEmoteListPage(0);

    auto bottomMenu = Build<CCMenu>::create()
        .pos(this->fromBottom(25.f))
        .contentSize({0, 0})
        .scale(0.66f)
        .id("bottom-menu")
        .parent(m_mainLayer);
    m_submitBtnSpr = ButtonSprite::create("Send Emote", "bigFont.fnt", "GJ_button_01.png");
    m_submitBtnSpr->setColor({100, 100, 100});
    m_submitBtnSpr->setCascadeColorEnabled(true);
    m_submitBtn = Build(m_submitBtnSpr)
        .intoMenuItem([this] {
            this->onSubmitBtn();
        })
        .id("emote-submit-btn")
        .scaleMult(1.15f)
        .parent(bottomMenu);
    m_submitBtn->setEnabled(false);

    auto infoMenu = Build<CCMenu>::create()
        .scale(0.75f)
        .pos(this->fromTopRight(16.f, 16.f))
        .contentSize({0, 0})
        .parent(m_mainLayer);
    auto infoBtn = Build<CCSprite>::createSpriteName("GJ_infoIcon_001.png")
        .intoMenuItem(+[] {
            globed::alert(
                "Emotes Guide",

                "Show an <co>emote</c> above your icon for other players to see in-game. Some emotes have <cp>sound effects</c> when used.\n\n"
                "PC users can set up to eight <cy>favorite emotes</c> and quickly use them with <cg>hotkeys</c>.\n\n"
                "There is a <cj>small cooldown</c> between sending emotes to prevent <cr>spam</c>."
            );
        })
        .parent(infoMenu);

    auto pageBtnMenu = Build<CCMenu>::create()
        .pos({0, 0})
        .contentSize(m_mainLayer->getContentSize())
        .parent(m_mainLayer);

    auto leftSpr = CCSprite::createWithSpriteFrameName("GJ_chatBtn_01_001.png");
    m_leftPageBtn = Build(leftSpr)
        .intoMenuItem([this] {
            this->updatePage(false);
        })
        .rotation(90.f)
        .pos(22.f, m_list->getPositionY() - LIST_SIZE.height / 2.f)
        .parent(pageBtnMenu);

    auto rightSpr = CCSprite::createWithSpriteFrameName("GJ_chatBtn_01_001.png");
    rightSpr->setFlipY(true);
    m_rightPageBtn = Build(rightSpr)
        .intoMenuItem([this] {
            this->updatePage(true);
        })
        .rotation(90.f)
        .pos(m_mainLayer->getContentWidth() - 22.f, m_list->getPositionY() - LIST_SIZE.height / 2.f)
        .parent(pageBtnMenu);



    m_bottomList = Build(cue::ListNode::create({LIST_SIZE.width, 35.f}, cue::Brown, cue::ListBorderStyle::Comments))
        .pos(this->fromBottom(68.f))
        .id("cursed-list")
        .parent(m_mainLayer);

    auto favoriteLabelMenu = Build<CCMenu>::create()
        .layout(RowLayout::create()->setAutoScale(false)->setGap(1.f))
        .contentSize(100.f, 0.f)
        .id("favorite-label-menu")
        .pos(this->fromBottom(95.f))
        .parent(m_mainLayer)
        .collect();

    auto favoriteLabel = Build<Label>::create("Favorites", "goldFont.fnt")
        .scale(0.4f)
        .parent(favoriteLabelMenu)
        .collect();

    // we may need to show a warning icon to make the usage clearer:
    // on desktop -> show if no keys are bound, explaining that it needs to be done
    // on mobile -> always show, explaining that the user must hold the emote button to quickly use favorites
    bool showWarning = GEODE_DESKTOP(!isAnyEmoteKeyBound()) GEODE_MOBILE(true);

    if (showWarning) {
        Build<CCSprite>::create("info-warning.png"_spr)
            .scale(0.5f)
            .intoMenuItem(+[] {
#ifdef GEODE_IS_DESKTOP
                globed::confirmPopup(
                    "No Keybinds",
                    "To be able to use <cg>favorite emotes</c> without <cy>pausing</c>, you need to set up the <cj>emote keybinds</c> in Globed settings. Want to open <cg>Keybind Settings</c> right now?",
                    "Cancel", "Ok",
                    [](auto) {
                        geode::openKeybindsPopup(std::nullopt, Mod::get());
                    }
                );
#else
                globed::alert(
                    "Favorite Emotes",
                    "After setting up <cg>favorite emotes</c> (by pressing a slot and choosing an emote), you can use them by <cy>holding</c> the <cj>Emote button</c> in the pause menu."
                );
#endif
            })
            .id("favorite-emote-warning")
            .parent(favoriteLabelMenu);
    }

    favoriteLabelMenu->updateLayout();

    m_favoriteEmotesMenu = Build<CCMenu>::create()
        .pos(this->fromBottom(70.f))
        .contentSize({(LIST_SIZE.width + 0.f) / 0.7f, 0})
        .anchorPoint(0.5f, 0.5f)
        .scale(0.7f)
        .layout(SimpleRowLayout::create()
            ->setMainAxisAlignment(MainAxisAlignment::Even)
        )
        .id("favorite-emote-menu")
        .parent(m_mainLayer);

    this->loadFavoriteEmotesList();

    m_favoriteHighlight = Build<CCScale9Sprite>::create("emote-btn-back.png"_spr)
        .contentSize({LIST_SIZE.width + 5.f, LIST_SIZE.height + 5.f})
        .pos(m_list->getPosition() + ccp(0, 2.5f))
        .anchorPoint(0.5f, 1.f)
        .color(ccColor3B(255, 230, 0))
        .opacity(30)
        .visible(false)
        .parent(m_mainLayer);
    m_favoriteHighlight->runAction(
        CCRepeatForever::create(
            CCSequence::create(
                CCFadeTo::create(0.8f, 150),
                CCFadeTo::create(0.8f, 30),
                nullptr
            )
        )
    );

    m_favoriteInfoLabel = Build<Label>::create(fmt::format("Choose an emote to add to favorites (Slot X)"), "bigFont.fnt")
        .scale(0.3f)
        .color(255, 230, 0)
        .pos(m_list->getPosition() + ccp(0, -LIST_SIZE.height - 2.f))
        .anchorPoint(0.5f, 0.5f)
        .zOrder(20)
        .visible(false)
        .parent(m_mainLayer);

    auto clearFavMenu = Build<CCMenu>::create()
        .pos({m_mainLayer->getContentWidth() - 40.f, 20.f})
        .contentSize({0, 0})
        .scale(0.4f)
        .parent(m_mainLayer);
    m_clearFavoriteBtn = Build(ButtonSprite::create("Remove", "goldFont.fnt", "GJ_button_05.png"))
        .intoMenuItem([this] {
            this->setFavorite(m_selectingFavoriteSlot, 0);
        })
        .id("emote-clear-btn")
        .scaleMult(1.15f)
        .parent(clearFavMenu);
    m_clearFavoriteBtn->setEnabled(false);
    m_clearFavoriteBtn->setVisible(false);

    // volume slider and label

    m_volumeSlider = Build(createSlider())
        .scale(0.85f)
        .id("volume-slider");

    m_volumeSlider->setContentWidth(80.f);
    m_volumeSlider->setRange(0.0, 1.0);
    m_volumeSlider->setValue(globed::setting<float>("core.player.quick-chat-sfx-volume"));
    m_volumeSlider->setCallback([](cue::Slider* slider, double value) {
        globed::setting<float>("core.player.quick-chat-sfx-volume") = value;
    });

    Build<Label>::create("Emote Volume", "bigFont.fnt")
        .scale(0.45f * 0.7f)
        .intoNewParent(CCNode::create())
        .id("volume-wrapper")
        .child(m_volumeSlider)
        .layout(ColumnLayout::create()
            ->setAutoScale(false)
            ->setAxisReverse(true))
        .contentSize(80.f, 30.f)
        .anchorPoint(0.5f, 0.5f)
        .pos(this->fromTopLeft(74.f, 22.f))
        .parent(m_mainLayer)
        .updateLayout();

    return true;
}


void EmoteListPopup::onSubmitBtn() {
    if (m_selectedEmoteId == (uint32_t)-1) {
        // do nothing (this shouldn't happen)
        return;
    }

    auto gjbgl = GlobedGJBGL::get();

    // check cooldown
    if (!gjbgl || !gjbgl->playSelfEmote(m_selectedEmoteId)) {
        // idk how to do this better
        m_submitBtnSpr->runAction(CCSequence::create(
            CCTintTo::create(0.05f, 255, 0, 0),
            CCTintTo::create(0.3f, 255, 255, 255),
            nullptr
        ));

        return;
    }

    this->onClose(this);

    FunctionQueue::get().queue([] {
        if (auto pause = CCScene::get()->getChildByType<PauseLayer>(0)) {
            pause->onResume(pause);
        }
    });
}

void EmoteListPopup::loadEmoteListPage(int page) {
    m_emoteMenu->removeAllChildrenWithCleanup(true);
    auto& em = EmoteManager::get();
    auto& emoteIds = em.getSortedEmoteIds();

    size_t start = page * EMOTES_PER_PAGE;
    size_t end = std::min(start + EMOTES_PER_PAGE, emoteIds.size());

    for (size_t i = start; i < end; i++) {
        uint32_t emoteId = emoteIds[i];
        bool selected = (emoteId == m_selectedEmoteId);
        auto sprite = em.createEmote(emoteId);

        if (!sprite) {
            log::warn("Emote ID {} is missing its sprite!", emoteId);
            continue;
        }

        auto* emoteBtn = Build<CCScale9Sprite>::create("emote-btn-back.png"_spr)
            .contentSize(35.f, 35.f)
            .color(selected ? ccColor3B(0, 255, 0) : ccColor3B(0, 0, 0))
            .opacity(180)
            .intoMenuItem([this, emoteId] {
                this->onEmoteBtn(emoteId);
            })
            .id(fmt::format("emote-btn-{}", emoteId))
            .scaleMult(1.1f)
            .parent(m_emoteMenu)
            .collect();

        sprite->setPosition(emoteBtn->getContentSize() / 2.f);
        emoteBtn->addChild(sprite, 5);
        cue::rescaleToMatch(sprite, 25.f);

        if (asp::iter::contains(m_favoriteEmoteIds, emoteId)) {
            CCSprite* star = Build<CCSprite>::createSpriteName("GJ_starsIcon_001.png")
                .scale(0.35f)
                .zOrder(5)
                .pos(emoteBtn->getContentWidth() - 6.f, 6.f)
                .parent(emoteBtn);
        }

        if (em.hasSfx(emoteId)) {
            Build<CCSprite>::create("speaker-icon.png"_spr)
                .scale(0.3f)
                .zOrder(6)
                .pos(6.f, emoteBtn->getContentHeight() - 5.f)
                .parent(emoteBtn);
        }
    }

    m_emoteMenu->updateLayout();
}

void EmoteListPopup::onEmoteBtn(uint32_t id) {
    // Emote select mode
    if (!m_isFavoriteMode) {
        m_selectedEmoteId = id;
        m_submitBtn->setEnabled(true);
        m_submitBtnSpr->setColor({255, 255, 255});

        this->loadEmoteListPage(m_selectedPage);
    } else { // Favorite emote select mode
        setFavorite(m_selectingFavoriteSlot, id);
    }
}

void EmoteListPopup::setFavorite(uint32_t emoteSlot, uint32_t id) {
    m_isFavoriteMode = false;
    m_favoriteEmoteIds[m_selectingFavoriteSlot] = id;
    m_selectingFavoriteSlot = (uint32_t)-1;
    this->loadFavoriteEmotesList();
    this->loadEmoteListPage(m_selectedPage);
    m_favoriteHighlight->setVisible(false);
    m_favoriteInfoLabel->setVisible(false);

    m_clearFavoriteBtn->setEnabled(false);
    m_clearFavoriteBtn->setVisible(false);

    globed::setValue(fmt::format("core.ui.emote-slot-{}", emoteSlot), id);
}

void EmoteListPopup::updatePage(bool increment) {
    if (increment) {
        if (m_selectedPage < m_maxPages - 1) {
            m_selectedPage++;
        } else {
            m_selectedPage = 0;
        }
    } else {
        if (m_selectedPage > 0) {
            m_selectedPage--;
        } else {
            m_selectedPage = m_maxPages - 1;
        }
    }
    m_pageLabel->setString(fmt::format("Page {} of {}", m_selectedPage + 1, m_maxPages).c_str());
    this->loadEmoteListPage(m_selectedPage);
}

void EmoteListPopup::enterFavoriteSelectMode(uint32_t emoteSlot) {
    // if the key for the slot isn't bound, do nothing on desktop, allow setting on mobile
    if (!isEmoteKeyBound(emoteSlot)) {
#ifdef GEODE_IS_DESKTOP
        globed::confirmPopup(
            "Key Not Bound",
            "This slot does not have a <cy>keybind</c> set up. To be able to quickly send emotes in levels, you need to set one up. Want to open <cg>Keybind Settings</c> now?",
            "Cancel", "Ok",
            [](auto) {
                geode::openKeybindsPopup(std::nullopt, Mod::get());
            }
        );
        return;
#endif
    }

    m_isFavoriteMode = true;
    m_selectingFavoriteSlot = emoteSlot;
    this->loadFavoriteEmotesList();
    m_favoriteHighlight->setVisible(true);
    m_favoriteInfoLabel->setString(fmt::format("Choose an emote to add to favorites (Slot {})", emoteSlot + 1).c_str());
    m_favoriteInfoLabel->setVisible(true);

    m_clearFavoriteBtn->setEnabled(true);
    m_clearFavoriteBtn->setVisible(true);
}

void EmoteListPopup::loadFavoriteEmotesList() {
    m_favoriteEmotesMenu->removeAllChildren();

    for (size_t i = 0; i < m_favoriteEmoteIds.size(); i++) {
        uint32_t emoteId = m_favoriteEmoteIds.at(i);
        bool selected = (i == m_selectingFavoriteSlot);

        auto sprite = EmoteManager::get().createEmote(emoteId);
        if (!sprite) {
            log::warn("Emote ID {} is missing its sprite!", emoteId);
            sprite = EmoteManager::get().createEmote(0);
        }

        auto emoteBtn = Build<CCScale9Sprite>::create("emote-btn-back.png"_spr)
            .contentSize(35.f, 35.f)
            .color(selected ? ccColor3B{255, 230, 0} : ccColor3B{0, 0, 0})
            .opacity(180)
            .intoMenuItem([this, i] {
                this->enterFavoriteSelectMode(i);
            })
            .id(fmt::format("emote-favorite-btn-{}", i))
            .scaleMult(1.1f)
            .parent(m_favoriteEmotesMenu)
            .collect();


        sprite->setPosition(emoteBtn->getContentSize() / 2.f);
        emoteBtn->addChild(sprite, 1);
        cue::rescaleToMatch(sprite, 25.f);

        auto slotLabel = Build<Label>::create(fmt::format("{}", i + 1), "goldFont.fnt")
            .scale(0.66f)
            .pos(emoteBtn->getContentSize().width / 2.f, -1.f);
        emoteBtn->addChild(slotLabel);
    }

    m_favoriteEmotesMenu->updateLayout();
}

EmoteListPopup* EmoteListPopup::create() {
    auto ret = new EmoteListPopup();
    if (ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

}