# ZFlip mods

Solo mods, sin launcher. Sube esto a un repositorio de GitHub, ve a **Actions → Build mods (.zflip) → Run workflow**
y descarga el artefacto `zflip-mods` (contiene un `.zflip` por mod).

* `mods/nongs/` — mod NONGs 1.1.0 (disco junto a la música en la página del nivel).
* `mods/hello/` — Mini Mod Menu 3.1.0 (noclip, velocidad que ahora funciona, desbloquear todos los iconos y colores).
* `mods/include/zflip.h` — API de ZFlip (la que ya usa tu launcher).
* Mod nuevo: crea `mods/<nombre>/` con `manifest.json`, `CMakeLists.txt` y `src/main.cpp`
  (copia `mods/nongs/` como plantilla). El workflow lo detecta solo.

El launcher instalado no cambia; el mod funciona con él tal como está.

## Workflows

* **Build mods (.zflip)** (`build-mods.yml`): compila los mods de `mods/*/`. También descomprime cualquier `.zip`
  que subas al repo (con la estructura `mods/<nombre>/...` o un mod suelto).
* **Build Geode (loader + mod) para GD 2.2091** (`build-geode-mods.yml`): compila desde el código fuente el loader de
  Geode y un mod `.geode` (por defecto Globed, `GlobedGD/globed2`). No necesita nada de `mods/`: clona el repo
  del mod que indiques en *Run workflow*. El resultado va al artefacto `geode-2.2091-build`.
